import { DetectionRule, EventLog, Alert } from '../types/security';
import { DEFAULT_DETECTION_RULES } from './sampleData';

export class RuleEngine {
  private rules: DetectionRule[];

  constructor(initialRules: DetectionRule[] = DEFAULT_DETECTION_RULES) {
    this.rules = [...initialRules];
  }

  getRules(): DetectionRule[] {
    return [...this.rules];
  }

  toggleRule(id: string): void {
    this.rules = this.rules.map(r => r.id === id ? { ...r, enabled: !r.enabled } : r);
  }

  updateRule(id: string, updates: Partial<DetectionRule>): void {
    this.rules = this.rules.map(r => r.id === id ? { ...r, ...updates } : r);
  }

  addRule(newRule: Omit<DetectionRule, 'id' | 'matchedCount'>): DetectionRule {
    const created: DetectionRule = {
      ...newRule,
      id: `RULE-${Math.floor(100 + Math.random() * 900)}`,
      matchedCount: 0
    };
    this.rules.push(created);
    return created;
  }

  deleteRule(id: string): void {
    this.rules = this.rules.filter(r => r.id !== id);
  }

  resetRules(): DetectionRule[] {
    this.rules = JSON.parse(JSON.stringify(DEFAULT_DETECTION_RULES));
    return this.rules;
  }

  evaluateLogs(logs: EventLog[]): Alert[] {
    const newAlerts: Alert[] = [];
    const ipFailures: Record<string, { count: number; lastTime: string; user: string }> = {};

    for (const log of logs) {
      if (log.eventType === 'auth_failed' && log.sourceIp) {
        if (!ipFailures[log.sourceIp]) {
          ipFailures[log.sourceIp] = { count: 0, lastTime: log.timestamp, user: log.user || 'unknown' };
        }
        ipFailures[log.sourceIp].count++;
      }

      // Check against enabled rules
      for (const rule of this.rules) {
        if (!rule.enabled) continue;

        let triggered = false;
        let alertDesc = '';

        if (rule.conditionType === 'failed_login_threshold' && log.sourceIp) {
          const stats = ipFailures[log.sourceIp];
          if (stats && stats.count >= (rule.threshold || 5)) {
            triggered = true;
            alertDesc = `Threshold exceeded: ${stats.count} failed authentications from ${log.sourceIp}`;
            rule.matchedCount++;
          }
        } else if (rule.conditionType === 'regex_pattern' && rule.pattern) {
          try {
            const re = new RegExp(rule.pattern, 'i');
            if (re.test(log.rawText)) {
              triggered = true;
              alertDesc = `Rule pattern match: [${rule.pattern}] in log stream`;
              rule.matchedCount++;
            }
          } catch (e) {
            // invalid regex safe skip
          }
        } else if (rule.conditionType === 'sudo_violation' && log.eventType === 'sudo_cmd') {
          if (log.severity === 'Critical') {
            triggered = true;
            alertDesc = `Unauthorized sudo attempt by user: ${log.user || 'service account'}`;
            rule.matchedCount++;
          }
        }

        if (triggered) {
          newAlerts.push({
            id: `ALT-GEN-${Math.floor(1000 + Math.random() * 9000)}`,
            timestamp: log.timestamp || new Date().toISOString().substring(11, 19),
            ruleName: `${rule.name} from ${log.sourceIp || log.host}`,
            agent: log.host || 'Agent-Generic',
            severity: rule.severity,
            sourceIp: log.sourceIp || '185.122.31.9',
            destIp: log.destIp || '10.0.1.4',
            status: 'Active',
            count: 1,
            mitreTactic: rule.mitreTactic,
            mitreTechniqueId: rule.mitreId,
            description: alertDesc || rule.description,
            rawLog: log.rawText,
            recommendation: rule.playbook,
            user: log.user,
            port: log.port || 22
          });
        }
      }
    }

    return newAlerts;
  }
}
