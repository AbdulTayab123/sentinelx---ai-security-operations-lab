import { Alert, Agent, EventLog, DetectionRule, ThreatNode, ThreatConnection, NetworkFlowDataPoint } from '../types/security';

export const INITIAL_ALERTS: Alert[] = [
  {
    id: 'ALT-9081',
    timestamp: '2023-10-27 14:38:21',
    ruleName: 'AWS: Potential brute-force attack from 185.122.31.9',
    agent: 'Agent-Web01',
    severity: 'Critical',
    sourceIp: '185.122.31.9',
    destIp: '185.122.31.9',
    status: 'Active',
    count: 147,
    mitreTactic: 'Credential Access',
    mitreTechniqueId: 'T1110.001 - Password Guessing',
    description: 'Rapid succession of failed SSH root and admin credential attempts (147 attempts within 45s). Consistent with automated password sprayer bot.',
    rawLog: 'Oct 27 14:38:21 web01 sshd[28412]: Failed password for invalid user admin from 185.122.31.9 port 49212 ssh2',
    recommendation: 'Temporarily isolate port 22 on perimeter firewall, add 185.122.31.9 to ipset blocklist, verify pam_faillock / fail2ban activation.',
    user: 'admin',
    port: 22,
    location: 'Kyiv, Ukraine'
  },
  {
    id: 'ALT-9082',
    timestamp: '2023-10-27 14:38:21',
    ruleName: 'AWS: Potential brute-force attack from 185.122.31.9',
    agent: 'Agent-Web02',
    severity: 'Critical',
    sourceIp: '185.122.31.9',
    destIp: '185.122.31.9',
    status: 'Active',
    count: 132,
    mitreTactic: 'Credential Access',
    mitreTechniqueId: 'T1110.003 - Password Spraying',
    description: 'Cross-host authentication spray targeting Web-02 cluster nodes from identical Ukraine subnet.',
    rawLog: 'Oct 27 14:38:21 web02 sshd[19044]: Failed password for root from 185.122.31.9 port 51104 ssh2',
    recommendation: 'Enable global GeoIP throttling on ingress gateways and verify PermitRootLogin no in sshd_config.',
    user: 'root',
    port: 22,
    location: 'Kyiv, Ukraine'
  },
  {
    id: 'ALT-9083',
    timestamp: '2023-10-27 14:38:21',
    ruleName: 'AWS: Potential brute-force attack from 185.122.31.9',
    agent: 'Agent-Web01',
    severity: 'High',
    sourceIp: '185.122.31.22',
    destIp: '185.122.31.9',
    status: 'Active',
    count: 89,
    mitreTactic: 'Initial Access',
    mitreTechniqueId: 'T1078 - Valid Accounts Probe',
    description: 'Secondary IP in /24 subnet testing default service accounts (postgres, redis, deploy).',
    rawLog: 'Oct 27 14:38:21 web01 sshd[28415]: Failed password for invalid user deploy from 185.122.31.22 port 38810 ssh2',
    recommendation: 'Block /24 CIDR prefix 185.122.31.0/24 on Cloudflare WAF / Security Group.',
    user: 'deploy',
    port: 22,
    location: 'Kyiv, Ukraine'
  },
  {
    id: 'ALT-9084',
    timestamp: '2023-10-27 14:38:21',
    ruleName: 'AWS: Potential brute-force attack from 185.122.31.9',
    agent: 'Agent-Web01',
    severity: 'High',
    sourceIp: '185.122.31.9',
    destIp: '185.122.31.9',
    status: 'Active',
    count: 76,
    mitreTactic: 'Discovery',
    mitreTechniqueId: 'T1046 - Network Service Scanning',
    description: 'Port sweep and TCP SYN anomalies detected across internal microservice endpoints.',
    rawLog: 'Oct 27 14:38:21 web01 kernel: [UFW BLOCK] IN=eth0 OUT= SRC=185.122.31.9 DST=10.0.1.4 PROTO=TCP SPT=49811 DPT=8080',
    recommendation: 'Review internal ingress NACL rules and enforce mTLS.',
    port: 8080,
    location: 'Kyiv, Ukraine'
  },
  {
    id: 'ALT-9085',
    timestamp: '2023-10-27 14:38:21',
    ruleName: 'AWS: Potential brute-force attack from 185.122.31.9',
    agent: 'Agent-Web01',
    severity: 'High',
    sourceIp: '185.122.31.9',
    destIp: '185.122.31.9',
    status: 'Active',
    count: 45,
    mitreTactic: 'Execution',
    mitreTechniqueId: 'T1059.004 - Unix Shell Command Injection',
    description: 'URI parameter malformation detected on /api/v1/debug query strings.',
    rawLog: 'Oct 27 14:38:21 web01 nginx[1410]: 185.122.31.9 - - [27/Oct/2023:14:38:21 +0000] "GET /api/v1/ping?host=127.0.0.1;cat+/etc/passwd HTTP/1.1" 403',
    recommendation: 'Audit web parameter input sanitation and enable ModSecurity OWASP Core Rule Set.',
    port: 443,
    location: 'Kyiv, Ukraine'
  },
  {
    id: 'ALT-9086',
    timestamp: '2023-10-27 14:35:10',
    ruleName: 'Database: Unauthorized Sudo Privilege Escalation Attempt',
    agent: 'Agent-DB02',
    severity: 'Critical',
    sourceIp: '103.45.98.11',
    destIp: '10.0.3.15',
    status: 'Active',
    count: 332,
    mitreTactic: 'Privilege Escalation',
    mitreTechniqueId: 'T1548.003 - Sudo and Sudo Caching Abuse',
    description: 'Service user www-data attempted executing /usr/bin/find with sudo privileges without tty allocation.',
    rawLog: 'Oct 27 14:35:10 db02 sudo[3021]: www-data : 3 incorrect password attempts ; TTY=unknown ; PWD=/var/www/html ; USER=root ; COMMAND=/usr/bin/find',
    recommendation: 'Revoke sudo nopasswd directives for web application accounts, audit /etc/sudoers.d/',
    user: 'www-data',
    port: 5432,
    location: 'Shenzhen, China'
  },
  {
    id: 'ALT-9087',
    timestamp: '2023-10-27 14:32:00',
    ruleName: 'VPN: Repeated Failed Multifactor Authentication',
    agent: 'Agent-VPN',
    severity: 'Medium',
    sourceIp: '103.45.98.13',
    destIp: '10.0.0.1',
    status: 'Active',
    count: 455,
    mitreTactic: 'Credential Access',
    mitreTechniqueId: 'T1621 - Multi-Factor Authentication Request Generation',
    description: 'High velocity MFA push notification fatigue detected for executive identity.',
    rawLog: 'Oct 27 14:32:00 vpn-gateway openvpn[1202]: AUTH_FAILED: RADIUS Duo push rejected timeout user=c_level_exec',
    recommendation: 'Enable number-matching MFA challenges and lock compromised user identity temporarily.',
    user: 'c_level_exec',
    port: 1194,
    location: 'Shenzhen, China'
  },
  {
    id: 'ALT-9088',
    timestamp: '2023-10-27 14:28:44',
    ruleName: 'Proxy: Anomalous Outbound Data Exfiltration Flow',
    agent: 'Agent-Proxy',
    severity: 'Critical',
    sourceIp: '103.45.98.1',
    destIp: '10.0.1.200',
    status: 'Active',
    count: 150,
    mitreTactic: 'Exfiltration',
    mitreTechniqueId: 'T1048 - Exfiltration Over Alternative Protocol',
    description: 'Isolation Forest flagged sudden 8.4GB encrypted data pipe burst on non-standard port 8443.',
    rawLog: 'Oct 27 14:28:44 proxy01 envoy[881]: FLOW_ALERT: egress burst 8940MB to external endpoint 103.45.98.1:8443 score=0.94',
    recommendation: 'Drop connection via egress proxy, isolate 10.0.1.200 host, pull RAM dump for volatility analysis.',
    port: 8443,
    location: 'Shenzhen, China'
  },
  {
    id: 'ALT-9089',
    timestamp: '2023-10-27 14:25:12',
    ruleName: 'Host: SUID Binary Binary Modified in /usr/bin',
    agent: 'Agent-Web02',
    severity: 'High',
    sourceIp: '185.133.36.4',
    destIp: '10.0.1.5',
    status: 'Active',
    count: 147,
    mitreTactic: 'Persistence',
    mitreTechniqueId: 'T1543 - Create or Modify System Process',
    description: 'File integrity monitoring (FIM / auditd) alerted on sha256 checksum change of /usr/bin/pkexec.',
    rawLog: 'Oct 27 14:25:12 web02 ossec: File /usr/bin/pkexec checksum changed from a1b8... to 99ff...',
    recommendation: 'Check AIDE integrity database, mount filesystem read-only, trigger incident response team.',
    location: 'St. Petersburg, Russia'
  },
  {
    id: 'ALT-9090',
    timestamp: '2023-10-27 14:20:00',
    ruleName: 'SSH: Known Botnet Reconnaissance Probing',
    agent: 'Agent-Auth01',
    severity: 'High',
    sourceIp: '103.6.1.64.5',
    destIp: '10.0.2.1',
    status: 'Active',
    count: 78,
    mitreTactic: 'Reconnaissance',
    mitreTechniqueId: 'T1595.002 - Vulnerability Scanning',
    description: 'Reputation threat feed match on known Mirai/Mozi botnet scan range.',
    rawLog: 'Oct 27 14:20:00 auth01 sshd[4401]: Disconnecting authenticating user root 103.6.1.64.5 port 55102: Change of username or service not allowed',
    recommendation: 'BGP blackhole route or perimeter drop rule.',
    port: 22,
    location: 'Hong Kong'
  },
  {
    id: 'ALT-9091',
    timestamp: '2023-10-27 14:15:30',
    ruleName: 'Policy: PCI-DSS Insecure Cipher Negotiation',
    agent: 'Agent-Web01',
    severity: 'Low',
    sourceIp: '163.45.834.8304',
    destIp: '10.0.1.4',
    status: 'Active',
    count: 31,
    mitreTactic: 'Defensive Evasion',
    mitreTechniqueId: 'T1573 - Encrypted Channel Degradation',
    description: 'Client requested TLS 1.0 handshake cipher suites RC4/3DES prohibited by organizational baseline.',
    rawLog: 'Oct 27 14:15:30 web01 nginx[1410]: SSL_do_handshake() failed (SSL: error:14201076:SSL routines:ssl_choose_client_version:unsupported protocol)',
    recommendation: 'Enforce minimum TLSv1.3 and modern cipher suites in nginx ssl_protocols directive.',
    port: 443,
    location: 'Frankfurt, Germany'
  }
];

export const INITIAL_AGENTS: Agent[] = [
  { id: 'agt-1', name: 'Agent-Web01', ip: '10.0.1.4', os: 'Ubuntu 22.04 LTS', status: 'Online', lastKeepAlive: '3s ago', version: 'v4.7.2', group: 'Web-Tier', activeAlerts: 147 },
  { id: 'agt-2', name: 'Agent-Web02', ip: '10.0.1.5', os: 'Ubuntu 22.04 LTS', status: 'Online', lastKeepAlive: '5s ago', version: 'v4.7.2', group: 'Web-Tier', activeAlerts: 132 },
  { id: 'agt-3', name: 'Agent-DB02', ip: '10.0.3.15', os: 'Debian 12 Bookworm', status: 'Online', lastKeepAlive: '2s ago', version: 'v4.7.2', group: 'Database-Cluster', activeAlerts: 332 },
  { id: 'agt-4', name: 'Agent-VPN', ip: '10.0.0.1', os: 'Rocky Linux 9.3', status: 'Online', lastKeepAlive: '8s ago', version: 'v4.7.2', group: 'Gateway', activeAlerts: 455 },
  { id: 'agt-5', name: 'Agent-Proxy', ip: '10.0.1.200', os: 'Alpine Linux 3.19', status: 'Online', lastKeepAlive: '1s ago', version: 'v4.7.2', group: 'Perimeter', activeAlerts: 150 },
  { id: 'agt-6', name: 'Agent-Auth01', ip: '10.0.2.1', os: 'Red Hat Enterprise Linux 9', status: 'Online', lastKeepAlive: '4s ago', version: 'v4.7.2', group: 'Identity', activeAlerts: 78 },
  { id: 'agt-7', name: 'Agent-DB01', ip: '10.0.3.14', os: 'Debian 12 Bookworm', status: 'Online', lastKeepAlive: '6s ago', version: 'v4.7.2', group: 'Database-Cluster', activeAlerts: 4 },
  { id: 'agt-8', name: 'Agent-KubeMaster', ip: '10.0.5.10', os: 'Ubuntu 22.04 LTS', status: 'Online', lastKeepAlive: '3s ago', version: 'v4.7.2', group: 'Kubernetes', activeAlerts: 9 },
  { id: 'agt-9', name: 'Agent-Backup01', ip: '10.0.8.50', os: 'FreeBSD 14.0', status: 'Offline', lastKeepAlive: '2h ago', version: 'v4.7.1', group: 'Storage', activeAlerts: 28 },
];

export const TOP_THREAT_SOURCES = [
  { ip: '185.122.31.9', count: 150, location: 'Ukraine', severity: 'Critical' },
  { ip: '103.45.98.11', count: 100, location: 'China', severity: 'Critical' },
  { ip: '103.45.98.38', count: 80, location: 'China', severity: 'High' },
  { ip: '185.122.32.33', count: 65, location: 'Ukraine', severity: 'High' },
  { ip: '103.45.88.39', count: 48, location: 'China', severity: 'High' },
  { ip: '103.45.98.26', count: 38, location: 'China', severity: 'High' },
  { ip: '103.45.98.1', count: 15, location: 'China', severity: 'Critical' },
];

export const MOST_TARGETED_ASSETS = [
  { name: 'Web-Prod-01', type: 'Frontend Ingress', attacks: 147, risk: 'Critical', ip: '10.0.1.4' },
  { name: 'DB-Cluster-02', type: 'PostgreSQL Primary', attacks: 112, risk: 'Critical', ip: '10.0.3.15' },
  { name: 'Corp-VPN', type: 'WireGuard / OpenVPN Gateway', attacks: 98, risk: 'High', ip: '10.0.0.1' },
  { name: 'Cerp-VPN', type: 'Legacy GlobalProtect Ingress', attacks: 84, risk: 'High', ip: '10.0.0.2' },
  { name: 'DB-Cluster-03', type: 'Analytics Replica', attacks: 61, risk: 'Medium', ip: '10.0.3.16' },
  { name: 'Corp-VPN', type: 'Staff SSL-VPN Endpoints', attacks: 52, risk: 'High', ip: '10.0.0.5' },
  { name: 'Web-Pred-01', type: 'Staging Ingress', attacks: 39, risk: 'Medium', ip: '10.0.1.9' },
];

export const ACTIVE_ALERT_SOURCE_IPS = [
  { ip: '185.122.31.9', agent: 'Agent-Web01', severity: 'Critical', count: 147 },
  { ip: '103.45.98.11', agent: 'Agent-DB02', severity: 'Critical', count: 332 },
  { ip: '103.45.98.13', agent: 'Agent-VPN', severity: 'Medium', count: 455 },
  { ip: '103.45.98.1', agent: 'Agent-Proxy', severity: 'Critical', count: 150 },
  { ip: '185.133.36.4', agent: 'Agent-Web02', severity: 'High', count: 147 },
  { ip: '103.6.1.64.5', agent: 'Agent-Auth01', severity: 'High', count: 78 },
  { ip: '163.45.834.8304', agent: 'Policy Violations', severity: 'Low', count: 31 },
];

export const ACTIVE_ALERT_RULES = [
  { rule: '185.122.33.97', agent: 'Agent-Web01', severity: 'Critical', count: 147 },
  { rule: '183.123.21.9', agent: 'Agent-DB02', severity: 'Critical', count: 148 },
  { rule: '185.625.18.14', agent: 'Agent-Web02', severity: 'High', count: 137 },
  { rule: '185.612.21.24', agent: 'Agent-VPN', severity: 'High', count: 317 },
  { rule: '163.68.9.12', agent: 'Agent-Auth01', severity: 'High', count: 87 },
  { rule: '185.122.18.03', agent: 'Agent-Proxy', severity: 'Critical', count: 87 },
];

export const THREAT_NODES: ThreatNode[] = [
  { id: 'node-ukraine', name: 'Ukraine', country: 'Ukraine', x: 57, y: 32, ip: '185.122.31.9', activeAttacks: 289, threatLevel: 'Critical' },
  { id: 'node-china', name: 'China', country: 'China', x: 76, y: 44, ip: '103.45.98.11', activeAttacks: 450, threatLevel: 'Critical' },
  { id: 'node-russia', name: 'Russia', country: 'Russia', x: 68, y: 26, ip: '185.133.36.4', activeAttacks: 172, threatLevel: 'High' },
  { id: 'node-brazil', name: 'Brazil', country: 'Brazil', x: 33, y: 72, ip: '177.54.12.8', activeAttacks: 88, threatLevel: 'Medium' },
  { id: 'node-us', name: 'United States (Target)', country: 'USA', x: 22, y: 38, ip: '10.0.1.4', activeAttacks: 0, threatLevel: 'Low' },
  { id: 'node-germany', name: 'Germany', country: 'Germany', x: 50, y: 31, ip: '163.45.83.4', activeAttacks: 42, threatLevel: 'Low' },
];

export const THREAT_CONNECTIONS: ThreatConnection[] = [
  {
    id: 'conn-1',
    source: THREAT_NODES[0], // Ukraine
    target: THREAT_NODES[4], // USA
    severity: 'Critical',
    attackType: 'SSH Distributed Brute Force'
  },
  {
    id: 'conn-2',
    source: THREAT_NODES[1], // China
    target: THREAT_NODES[4], // USA
    severity: 'Critical',
    attackType: 'Database Port Injection & MFA Fatigue'
  },
  {
    id: 'conn-3',
    source: THREAT_NODES[2], // Russia
    target: THREAT_NODES[4], // USA
    severity: 'High',
    attackType: 'SUID Privilege Escalation & Scanner'
  },
  {
    id: 'conn-4',
    source: THREAT_NODES[3], // Brazil
    target: THREAT_NODES[4], // USA
    severity: 'Medium',
    attackType: 'WordPress XML-RPC Amplification'
  },
  {
    id: 'conn-5',
    source: THREAT_NODES[1], // China
    target: THREAT_NODES[0], // Ukraine
    severity: 'High',
    attackType: 'Cross-Proxy Relay Chain'
  }
];

export const DEFAULT_DETECTION_RULES: DetectionRule[] = [
  {
    id: 'RULE-101',
    name: 'SSH Brute-Force Password Spray',
    description: 'Triggers when 5 or more authentication failures occur from the same remote IP within 60 seconds.',
    severity: 'Critical',
    enabled: true,
    category: 'Authentication',
    conditionType: 'failed_login_threshold',
    threshold: 5,
    windowSeconds: 60,
    matchedCount: 289,
    mitreId: 'T1110',
    mitreTactic: 'Credential Access',
    playbook: 'Check ipset table, add ban entry via iptables/nftables, enforce fail2ban maxretry=3.'
  },
  {
    id: 'RULE-102',
    name: 'Invalid User Login Enumeration',
    description: 'Flags SSH login attempts with non-existent system user accounts (e.g. admin, test, guest, nagios).',
    severity: 'High',
    enabled: true,
    category: 'Authentication',
    conditionType: 'regex_pattern',
    pattern: 'Invalid user (admin|guest|test|deploy|oracle|ubnt|postgres)',
    matchedCount: 142,
    mitreId: 'T1087',
    mitreTactic: 'Account Discovery',
    playbook: 'Ensure users do not exist; inspect auth log origin IP for automated scanning campaigns.'
  },
  {
    id: 'RULE-103',
    name: 'Direct Root SSH Authentication Attempt',
    description: 'Flags any SSH authentication attempts directed specifically at the root account.',
    severity: 'High',
    enabled: true,
    category: 'Authentication',
    conditionType: 'regex_pattern',
    pattern: 'Failed password for root from',
    matchedCount: 97,
    mitreId: 'T1078.003',
    mitreTactic: 'Initial Access',
    playbook: 'Enforce "PermitRootLogin no" in /etc/ssh/sshd_config and reload sshd.'
  },
  {
    id: 'RULE-104',
    name: 'Sudoers Privilege Escalation Failure',
    description: 'Detects 3 or more failed sudo execution attempts or unauthorized sudo invocations.',
    severity: 'Critical',
    enabled: true,
    category: 'Privilege',
    conditionType: 'sudo_violation',
    threshold: 3,
    windowSeconds: 120,
    matchedCount: 46,
    mitreId: 'T1548.003',
    mitreTactic: 'Privilege Escalation',
    playbook: 'Review /var/log/auth.log sudo line, audit user terminal session, lock account if unauthorized.'
  },
  {
    id: 'RULE-105',
    name: 'Rapid Port Sweep / Port Scan',
    description: 'Detects connection attempts to 10+ distinct closed ports from a single source within 30 seconds.',
    severity: 'High',
    enabled: true,
    category: 'Network',
    conditionType: 'port_scan',
    threshold: 10,
    windowSeconds: 30,
    matchedCount: 84,
    mitreId: 'T1046',
    mitreTactic: 'Network Service Discovery',
    playbook: 'Rate limit TCP SYN packets in firewall, check Suricata / Snort alert correlation.'
  },
  {
    id: 'RULE-106',
    name: 'Machine Learning Anomaly Score Threshold Exceeded',
    description: 'Flags network flow records where Isolation Forest calculates an anomaly score > 0.70.',
    severity: 'Critical',
    enabled: true,
    category: 'System',
    conditionType: 'anomaly_score',
    threshold: 70,
    matchedCount: 118,
    mitreId: 'T1071',
    mitreTactic: 'Command and Control / Exfiltration',
    playbook: 'Examine flow duration, bytes ratio, and dest port. Check for covert DNS/ICMP tunneling.'
  }
];

export const SAMPLE_AUTH_LOG = `Oct 27 14:38:01 web01 sshd[28400]: Failed password for invalid user admin from 185.122.31.9 port 49200 ssh2
Oct 27 14:38:05 web01 sshd[28402]: Failed password for invalid user admin from 185.122.31.9 port 49202 ssh2
Oct 27 14:38:09 web01 sshd[28404]: Failed password for invalid user admin from 185.122.31.9 port 49204 ssh2
Oct 27 14:38:12 web01 sshd[28407]: Failed password for invalid user support from 185.122.31.9 port 49207 ssh2
Oct 27 14:38:16 web01 sshd[28410]: Failed password for root from 185.122.31.9 port 49210 ssh2
Oct 27 14:38:21 web01 sshd[28412]: Failed password for invalid user admin from 185.122.31.9 port 49212 ssh2
Oct 27 14:38:23 web01 sshd[28415]: Failed password for invalid user deploy from 185.122.31.22 port 38810 ssh2
Oct 27 14:35:10 db02 sudo[3021]: www-data : 3 incorrect password attempts ; TTY=unknown ; PWD=/var/www/html ; USER=root ; COMMAND=/usr/bin/find
Oct 27 14:35:12 db02 sudo[3024]: pam_unix(sudo:auth): authentication failure; logname= uid=33 euid=0 tty= ruser=www-data rhost= user=www-data
Oct 27 14:36:01 web01 sshd[28420]: Accepted publickey for ubuntu from 10.0.1.200 port 54112 ssh2: RSA SHA256:7uK+...
Oct 27 14:36:02 web01 systemd-logind[788]: New session 429 of user ubuntu.
Oct 27 14:37:15 db02 sshd[1908]: Failed password for postgres from 103.45.98.11 port 52140 ssh2
Oct 27 14:37:18 db02 sshd[1910]: Failed password for postgres from 103.45.98.11 port 52142 ssh2
Oct 27 14:37:22 db02 sshd[1914]: Failed password for invalid user test from 103.45.98.11 port 52146 ssh2
Oct 27 14:37:25 db02 sshd[1918]: Failed password for root from 103.45.98.11 port 52150 ssh2`;

export const SAMPLE_NETWORK_FLOW_CSV = `timestamp,duration,protocol,src_bytes,dst_bytes,packet_rate,error_rate,same_srv_rate,label
2023-10-27 14:38:00,0.02,TCP,240,480,12.5,0.0,1.0,0
2023-10-27 14:38:01,0.01,TCP,180,240,8.3,0.0,1.0,0
2023-10-27 14:38:02,14.8,TCP,1458000,420,184.2,0.85,0.12,1
2023-10-27 14:38:03,0.03,TCP,320,640,15.1,0.0,1.0,0
2023-10-27 14:38:04,22.1,TCP,8940000,120,410.5,0.92,0.05,1
2023-10-27 14:38:05,0.01,UDP,64,64,2.0,0.0,1.0,0
2023-10-27 14:38:06,0.05,TCP,512,1024,20.0,0.0,1.0,0
2023-10-27 14:38:07,31.5,TCP,6500000,320,295.0,0.78,0.18,1
2023-10-27 14:38:08,0.02,TCP,190,380,9.5,0.0,1.0,0
2023-10-27 14:38:09,0.01,TCP,220,440,11.0,0.0,1.0,0
2023-10-27 14:38:10,18.4,TCP,4200000,210,340.0,0.88,0.08,1
2023-10-27 14:38:11,0.03,TCP,280,560,14.0,0.0,1.0,0
2023-10-27 14:38:12,0.02,TCP,240,480,12.0,0.0,1.0,0
2023-10-27 14:38:13,28.0,TCP,9800000,180,485.0,0.95,0.02,1
2023-10-27 14:38:14,0.01,TCP,150,300,7.5,0.0,1.0,0
2023-10-27 14:38:15,0.02,UDP,128,128,4.0,0.0,1.0,0
2023-10-27 14:38:16,12.2,TCP,3400000,510,210.0,0.81,0.15,1
2023-10-27 14:38:17,0.02,TCP,210,420,10.5,0.0,1.0,0
2023-10-27 14:38:18,0.03,TCP,300,600,15.0,0.0,1.0,0
2023-10-27 14:38:19,25.6,TCP,7850000,290,360.0,0.91,0.07,1
2023-10-27 14:38:20,0.01,TCP,180,360,9.0,0.0,1.0,0`;

export const SAMPLE_SYSLOG = `Oct 27 14:38:21 web01 nginx[1410]: 185.122.31.9 - - [27/Oct/2023:14:38:21 +0000] "GET /wp-login.php HTTP/1.1" 404 153 "-" "Mozilla/5.0"
Oct 27 14:38:21 web01 nginx[1410]: 185.122.31.9 - - [27/Oct/2023:14:38:21 +0000] "POST /xmlrpc.php HTTP/1.1" 403 162 "-" "curl/7.81.0"
Oct 27 14:38:21 web01 nginx[1410]: 185.122.31.9 - - [27/Oct/2023:14:38:21 +0000] "GET /api/v1/ping?host=127.0.0.1;cat+/etc/passwd HTTP/1.1" 403 218 "-" "python-requests/2.28"
Oct 27 14:38:21 web01 kernel: [UFW BLOCK] IN=eth0 OUT= MAC=00:16:3e:44:88:99:00:25:90:7b:6c:e1:08:00 SRC=185.122.31.9 DST=10.0.1.4 LEN=60 TOS=0x00 PREC=0x00 TTL=51 ID=39011 DF PROTO=TCP SPT=49811 DPT=8080 WINDOW=64240 RES=0x00 SYN URGP=0
Oct 27 14:38:21 web01 ossec: Alert [100201] Level 10: Multiple unauthorized web probing attempts from 185.122.31.9`;
