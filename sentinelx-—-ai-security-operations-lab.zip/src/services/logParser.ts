import { EventLog, Severity, NetworkFlowDataPoint } from '../types/security';

export interface ParseResult {
  logs: EventLog[];
  errors: string[];
  summary: {
    totalParsed: number;
    failedAuthCount: number;
    successfulAuthCount: number;
    sudoViolations: number;
    uniqueIPs: string[];
    uniqueUsers: string[];
  };
}

export function parseLinuxAuthLog(rawContent: string, defaultHost = 'linux-host'): ParseResult {
  const lines = rawContent.split(/\r?\n/);
  const logs: EventLog[] = [];
  const errors: string[] = [];
  const uniqueIPs = new Set<string>();
  const uniqueUsers = new Set<string>();
  let failedAuthCount = 0;
  let successfulAuthCount = 0;
  let sudoViolations = 0;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;

    try {
      // Example: Oct 27 14:38:21 web01 sshd[28412]: Failed password for invalid user admin from 185.122.31.9 port 49212 ssh2
      // Example: Oct 27 14:35:10 db02 sudo[3021]: www-data : 3 incorrect password attempts ...
      const timestampMatch = line.match(/^([A-Za-z]{3}\s+\d+\s+\d{2}:\d{2}:\d{2})/);
      const timestamp = timestampMatch ? timestampMatch[1] : 'Unknown Time';

      const hostMatch = line.match(/^[A-Za-z]{3}\s+\d+\s+\d{2}:\d{2}:\d{2}\s+([a-zA-Z0-9_\-\.]+)/);
      const host = hostMatch ? hostMatch[1] : defaultHost;

      const serviceMatch = line.match(/\s+([a-zA-Z0-9_\-\.]+)(?:\[\d+\])?:\s+(.*)$/);
      const service = serviceMatch ? serviceMatch[1] : 'auth';
      const message = serviceMatch ? serviceMatch[2] : line;

      let eventType: EventLog['eventType'] = 'system';
      let severity: Severity = 'Low';
      let user: string | undefined;
      let sourceIp: string | undefined;
      let port: number | undefined;

      // Extract IP address if present
      const ipMatch = line.match(/\b(?:from\s+)?((?:[0-9]{1,3}\.){3}[0-9]{1,3})\b/);
      if (ipMatch) {
        sourceIp = ipMatch[1];
        uniqueIPs.add(sourceIp);
      }

      // Extract Port
      const portMatch = line.match(/\bport\s+(\d+)\b/);
      if (portMatch) {
        port = parseInt(portMatch[1], 10);
      }

      // 1. Failed password / authentication
      if (line.includes('Failed password') || line.includes('authentication failure')) {
        eventType = 'auth_failed';
        failedAuthCount++;
        severity = line.includes('invalid user') || line.includes('root') ? 'High' : 'Medium';

        const userMatch = line.match(/(?:for\s+(?:invalid\s+user\s+)?|user=)([a-zA-Z0-9_\-\.]+)/i);
        if (userMatch) {
          user = userMatch[1];
          uniqueUsers.add(user);
        }
      }
      // 2. Accepted password / publickey
      else if (line.includes('Accepted password') || line.includes('Accepted publickey')) {
        eventType = 'auth_success';
        successfulAuthCount++;
        severity = 'Low';

        const userMatch = line.match(/for\s+([a-zA-Z0-9_\-\.]+)/i);
        if (userMatch) {
          user = userMatch[1];
          uniqueUsers.add(user);
        }
      }
      // 3. Sudo violations or commands
      else if (line.includes('sudo:') || line.includes('COMMAND=') || line.includes('incorrect password attempts')) {
        eventType = 'sudo_cmd';
        if (line.includes('incorrect password') || line.includes('NOT in sudoers')) {
          sudoViolations++;
          severity = 'Critical';
        } else {
          severity = 'Medium';
        }

        const userMatch = line.match(/sudo\[\d+\]:\s+([a-zA-Z0-9_\-\.]+)/i);
        if (userMatch) {
          user = userMatch[1];
          uniqueUsers.add(user);
        }
      }
      // 4. Invalid user enumeration
      else if (line.includes('Invalid user')) {
        eventType = 'auth_failed';
        severity = 'High';
        const userMatch = line.match(/Invalid user\s+([a-zA-Z0-9_\-\.]+)/i);
        if (userMatch) {
          user = userMatch[1];
          uniqueUsers.add(user);
        }
      }
      // 5. Firewall / UFW
      else if (line.includes('[UFW BLOCK]') || line.includes('iptables')) {
        eventType = 'port_scan';
        severity = 'Medium';
      }

      logs.push({
        id: `evt-${i + 1}-${Date.now().toString(36)}`,
        timestamp,
        host,
        service,
        eventType,
        message,
        user,
        sourceIp,
        destIp: '10.0.1.4',
        port,
        rawText: line,
        severity
      });
    } catch (err: any) {
      errors.push(`Line ${i + 1}: ${err?.message || 'Parse error'}`);
    }
  }

  return {
    logs,
    errors,
    summary: {
      totalParsed: logs.length,
      failedAuthCount,
      successfulAuthCount,
      sudoViolations,
      uniqueIPs: Array.from(uniqueIPs),
      uniqueUsers: Array.from(uniqueUsers)
    }
  };
}

export function parseNetworkFlowCsv(rawCsv: string): { data: NetworkFlowDataPoint[]; errors: string[] } {
  const lines = rawCsv.split(/\r?\n/).filter(l => l.trim().length > 0);
  const data: NetworkFlowDataPoint[] = [];
  const errors: string[] = [];

  if (lines.length < 2) {
    return { data, errors: ['CSV file is empty or missing headers'] };
  }

  const headerLine = lines[0].toLowerCase();
  const headers = headerLine.split(',').map(h => h.trim());

  const idxDuration = headers.findIndex(h => h.includes('duration'));
  const idxProto = headers.findIndex(h => h.includes('proto'));
  const idxSrcBytes = headers.findIndex(h => h.includes('src_bytes') || h.includes('srcbytes'));
  const idxDstBytes = headers.findIndex(h => h.includes('dst_bytes') || h.includes('dstbytes'));
  const idxRate = headers.findIndex(h => h.includes('rate') || h.includes('pkt') || h.includes('packet'));
  const idxErr = headers.findIndex(h => h.includes('err') || h.includes('error'));
  const idxSrv = headers.findIndex(h => h.includes('same_srv') || h.includes('srv'));
  const idxLabel = headers.findIndex(h => h.includes('label') || h.includes('class') || h.includes('target'));

  for (let i = 1; i < lines.length; i++) {
    const row = lines[i].split(',').map(r => r.trim());
    if (row.length < 3) continue;

    try {
      const duration = idxDuration >= 0 ? parseFloat(row[idxDuration]) || 0.01 : 0.05;
      const protoRaw = idxProto >= 0 ? row[idxProto].toUpperCase() : 'TCP';
      const protocol = (protoRaw.includes('UDP') ? 'UDP' : protoRaw.includes('ICMP') ? 'ICMP' : 'TCP') as 'TCP' | 'UDP' | 'ICMP';
      const srcBytes = idxSrcBytes >= 0 ? parseFloat(row[idxSrcBytes]) || 100 : 256;
      const dstBytes = idxDstBytes >= 0 ? parseFloat(row[idxDstBytes]) || 200 : 512;
      const packetRate = idxRate >= 0 ? parseFloat(row[idxRate]) || 10 : 12;
      const errorRate = idxErr >= 0 ? parseFloat(row[idxErr]) || 0 : 0;
      const sameSrvRate = idxSrv >= 0 ? parseFloat(row[idxSrv]) || 1.0 : 1.0;
      
      let groundTruthLabel: 0 | 1 | undefined = undefined;
      if (idxLabel >= 0) {
        const val = row[idxLabel].toLowerCase();
        groundTruthLabel = (val === '1' || val === 'anomaly' || val === 'attack') ? 1 : 0;
      }

      data.push({
        id: `flow-${i}`,
        timestamp: row[0] && row[0].includes(':') ? row[0] : new Date(Date.now() - (lines.length - i) * 60000).toISOString().replace('T', ' ').substring(0, 19),
        duration,
        protocol,
        srcBytes,
        dstBytes,
        packetRate,
        errorRate,
        sameSrvRate,
        anomalyScore: 0,
        isAnomaly: false,
        groundTruthLabel,
        flaggedReason: 'Evaluating...'
      });
    } catch (err: any) {
      errors.push(`Row ${i + 1}: ${err.message}`);
    }
  }

  return { data, errors };
}
