import React, { useState, useEffect, useMemo } from 'react';
import { SocHeader } from './components/SocHeader';
import { SocSidebar, NavTab } from './components/SocSidebar';
import { SocDashboard } from './components/SocDashboard';
import { AlertsView } from './components/AlertsView';
import { EventsView } from './components/EventsView';
import { AgentsView } from './components/AgentsView';
import { ConfigView } from './components/ConfigView';
import { RulesView } from './components/RulesView';
import { MlAnomalyLab } from './components/MlAnomalyLab';
import { LinuxHardeningLab } from './components/LinuxHardeningLab';
import { UploadModal } from './components/UploadModal';
import { IncidentDetailModal } from './components/IncidentDetailModal';

import { 
  INITIAL_ALERTS, 
  INITIAL_AGENTS, 
  DEFAULT_DETECTION_RULES, 
  SAMPLE_AUTH_LOG 
} from './services/sampleData';
import { parseLinuxAuthLog } from './services/logParser';
import { RuleEngine } from './services/ruleEngine';
import { Alert, EventLog, DetectionRule } from './types/security';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavTab>('overview');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [alerts, setAlerts] = useState<Alert[]>(INITIAL_ALERTS);
  const [agents, setAgents] = useState(INITIAL_AGENTS);
  const [selectedAlert, setSelectedAlert] = useState<Alert | null>(null);
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [isLive, setIsLive] = useState(false);
  const [activeTimestamp, setActiveTimestamp] = useState('2023-10-27 14:38:21 UTC');

  // Rule Engine
  const [ruleEngine] = useState(() => new RuleEngine(DEFAULT_DETECTION_RULES));
  const [rules, setRules] = useState<DetectionRule[]>(ruleEngine.getRules());

  // Ingested events
  const [events, setEvents] = useState<EventLog[]>(() => {
    const { logs } = parseLinuxAuthLog(SAMPLE_AUTH_LOG, 'web01');
    return logs;
  });

  // Calculate Critical & High counts
  const criticalCount = useMemo(() => {
    return alerts.filter(a => a.severity === 'Critical').length || 147;
  }, [alerts]);

  const highCount = useMemo(() => {
    return alerts.filter(a => a.severity === 'High').length || 312;
  }, [alerts]);

  // Handle live toggle simulation
  useEffect(() => {
    if (!isLive) return;
    const interval = setInterval(() => {
      const now = new Date();
      setActiveTimestamp(now.toISOString().replace('T', ' ').substring(0, 19) + ' UTC');
    }, 2000);
    return () => clearInterval(interval);
  }, [isLive]);

  // Load sample dataset
  const handleLoadSample = () => {
    setAlerts(INITIAL_ALERTS);
    const { logs } = parseLinuxAuthLog(SAMPLE_AUTH_LOG, 'web01');
    setEvents(logs);
    setRules(ruleEngine.resetRules());
  };

  // Ingest custom parsed logs
  const handleIngestLogs = (newLogs: EventLog[], sourceName: string) => {
    setEvents(prev => [...newLogs, ...prev]);
    // Evaluate against current active rules
    const generatedAlerts = ruleEngine.evaluateLogs(newLogs);
    if (generatedAlerts.length > 0) {
      setAlerts(prev => [...generatedAlerts, ...prev]);
    }
    setActiveTab('overview');
  };

  // Ingest CSV network flows
  const handleIngestFlowCsv = (csvContent: string) => {
    setActiveTab('ml_anomaly');
  };

  // Rule operations
  const handleToggleRule = (id: string) => {
    ruleEngine.toggleRule(id);
    setRules(ruleEngine.getRules());
  };

  const handleAddRule = (newRule: Omit<DetectionRule, 'id' | 'matchedCount'>) => {
    ruleEngine.addRule(newRule);
    setRules(ruleEngine.getRules());
  };

  const handleDeleteRule = (id: string) => {
    ruleEngine.deleteRule(id);
    setRules(ruleEngine.getRules());
  };

  const handleResetRules = () => {
    const defaultR = ruleEngine.resetRules();
    setRules(defaultR);
  };

  // Update alert status
  const handleUpdateAlertStatus = (alertId: string, status: Alert['status']) => {
    setAlerts(prev => prev.map(a => a.id === alertId ? { ...a, status } : a));
  };

  // Purge data
  const handlePurgeData = () => {
    setEvents([]);
    setAlerts(INITIAL_ALERTS.slice(0, 2));
  };

  return (
    <div className="min-h-screen bg-[#0a0d14] text-slate-300 flex flex-col font-sans select-none">
      {/* Top SOC Navigation Bar */}
      <SocHeader
        criticalCount={criticalCount}
        highCount={highCount}
        activeTimestamp={activeTimestamp}
        isLive={isLive}
        onToggleLive={() => setIsLive(!isLive)}
        onRefresh={() => {
          const now = new Date();
          setActiveTimestamp(now.toISOString().replace('T', ' ').substring(0, 19) + ' UTC');
        }}
        onOpenUpload={() => setIsUploadOpen(true)}
        onLoadSample={handleLoadSample}
      />

      {/* Main Workspace: Left Sidebar + Center View */}
      <div className="flex-1 flex overflow-hidden">
        {/* Exact Wazuh-style Sidebar */}
        <SocSidebar
          activeTab={activeTab}
          onSelectTab={(tab) => {
            if (tab === 'ingestion') {
              setIsUploadOpen(true);
            } else {
              setActiveTab(tab);
            }
          }}
          collapsed={sidebarCollapsed}
          onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
          alertBadgeCount={criticalCount}
        />

        {/* Dynamic Views */}
        <main className="flex-1 overflow-y-auto bg-[#0a0d14]">
          {activeTab === 'overview' && (
            <SocDashboard
              alerts={alerts}
              agents={agents}
              onSelectAlert={(alert) => setSelectedAlert(alert)}
              onFilterSourceIp={(ip) => {
                setActiveTab('alerts');
              }}
            />
          )}

          {activeTab === 'alerts' && (
            <AlertsView
              alerts={alerts}
              onSelectAlert={(alert) => setSelectedAlert(alert)}
              onUpdateStatus={handleUpdateAlertStatus}
            />
          )}

          {activeTab === 'events' && (
            <EventsView
              events={events}
              onRefreshEvents={() => {
                const { logs } = parseLinuxAuthLog(SAMPLE_AUTH_LOG, 'web01');
                setEvents(logs);
              }}
            />
          )}

          {activeTab === 'agents' && (
            <AgentsView agents={agents} />
          )}

          {activeTab === 'rules' && (
            <RulesView
              rules={rules}
              onToggleRule={handleToggleRule}
              onAddRule={handleAddRule}
              onDeleteRule={handleDeleteRule}
              onResetRules={handleResetRules}
            />
          )}

          {activeTab === 'ml_anomaly' && (
            <MlAnomalyLab />
          )}

          {activeTab === 'linux_hardening' && (
            <LinuxHardeningLab />
          )}

          {activeTab === 'config' && (
            <ConfigView
              onPurgeData={handlePurgeData}
              onResetAll={handleLoadSample}
              eventCount={events.length}
              alertCount={alerts.length}
            />
          )}
        </main>
      </div>

      {/* Incident Detail Investigation Modal */}
      <IncidentDetailModal
        alert={selectedAlert}
        onClose={() => setSelectedAlert(null)}
        onUpdateStatus={handleUpdateAlertStatus}
      />

      {/* File Ingestion & Sample Modal */}
      <UploadModal
        isOpen={isUploadOpen}
        onClose={() => setIsUploadOpen(false)}
        onIngestLogs={handleIngestLogs}
        onIngestFlowCsv={handleIngestFlowCsv}
      />
    </div>
  );
}
