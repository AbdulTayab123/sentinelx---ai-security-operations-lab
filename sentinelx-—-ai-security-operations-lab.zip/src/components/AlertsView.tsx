import React, { useState, useMemo } from 'react';
import { Search, Filter, Download, ArrowUpDown, ShieldAlert, CheckCircle, Clock } from 'lucide-react';
import { Alert, Severity } from '../types/security';

interface AlertsViewProps {
  alerts: Alert[];
  onSelectAlert: (alert: Alert) => void;
  onUpdateStatus: (alertId: string, status: Alert['status']) => void;
}

export const AlertsView: React.FC<AlertsViewProps> = ({
  alerts,
  onSelectAlert,
  onUpdateStatus
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSeverity, setSelectedSeverity] = useState<string>('ALL');
  const [selectedStatus, setSelectedStatus] = useState<string>('ALL');

  const filteredAlerts = useMemo(() => {
    return alerts.filter(alert => {
      const matchesSearch = 
        alert.ruleName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        alert.sourceIp.toLowerCase().includes(searchTerm.toLowerCase()) ||
        alert.agent.toLowerCase().includes(searchTerm.toLowerCase()) ||
        alert.id.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesSeverity = selectedSeverity === 'ALL' || alert.severity === selectedSeverity;
      const matchesStatus = selectedStatus === 'ALL' || alert.status === selectedStatus;

      return matchesSearch && matchesSeverity && matchesStatus;
    });
  }, [alerts, searchTerm, selectedSeverity, selectedStatus]);

  const handleExportCsv = () => {
    const headers = ['ID', 'Timestamp', 'RuleName', 'Agent', 'Severity', 'SourceIP', 'DestIP', 'Status', 'Count'];
    const rows = filteredAlerts.map(a => [
      a.id,
      a.timestamp,
      `"${a.ruleName.replace(/"/g, '""')}"`,
      a.agent,
      a.severity,
      a.sourceIp,
      a.destIp,
      a.status,
      a.count
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `sentinelx-alerts-${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    link.remove();
  };

  return (
    <div className="p-4 space-y-4 font-mono select-none">
      {/* Top Filter and Controls Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-[#111622] p-3 rounded border border-[#1b2536]">
        <div className="flex flex-wrap items-center gap-2 flex-1 min-w-[280px]">
          {/* Search input */}
          <div className="relative flex-1 min-w-[200px]">
            <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-2.5" />
            <input
              type="text"
              placeholder="Filter by IP, rule name, host..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-[#0b0e14] border border-[#1e2a3c] rounded pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500"
            />
          </div>

          {/* Severity Filter Pills */}
          <div className="flex items-center space-x-1 text-xs">
            {['ALL', 'Critical', 'High', 'Medium', 'Low'].map((sev) => (
              <button
                key={sev}
                onClick={() => setSelectedSeverity(sev)}
                className={`px-2 py-1 rounded text-[11px] transition-colors ${
                  selectedSeverity === sev
                    ? 'bg-cyan-900 text-cyan-200 border border-cyan-600 font-bold'
                    : 'bg-[#162030] text-slate-400 hover:text-slate-200 border border-[#1c293e]'
                }`}
              >
                {sev}
              </button>
            ))}
          </div>
        </div>

        {/* Export & Counter */}
        <div className="flex items-center space-x-3">
          <span className="text-xs text-slate-400">
            {filteredAlerts.length} incidents found
          </span>
          <button
            onClick={handleExportCsv}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded bg-[#162030] hover:bg-[#1e2b40] text-slate-200 border border-slate-700 text-xs transition-colors"
          >
            <Download className="w-3.5 h-3.5 text-cyan-400" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Main Alerts Table */}
      <div className="bg-[#111622] border border-[#1b2536] rounded overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-[#0c1018] text-slate-400 border-b border-[#1b2536] text-[11px]">
                <th className="py-2.5 px-3">Alert ID</th>
                <th className="py-2.5 px-3">Timestamp</th>
                <th className="py-2.5 px-3">Rule / Signature</th>
                <th className="py-2.5 px-3">Severity</th>
                <th className="py-2.5 px-3">Target Host</th>
                <th className="py-2.5 px-3">Source IP</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#172030]">
              {filteredAlerts.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-500">
                    No security alerts matching current filter criteria.
                  </td>
                </tr>
              ) : (
                filteredAlerts.map((alert) => (
                  <tr
                    key={alert.id}
                    onClick={() => onSelectAlert(alert)}
                    className="hover:bg-[#151e2d] cursor-pointer transition-colors group"
                  >
                    <td className="py-2.5 px-3 font-bold text-slate-300">
                      {alert.id}
                    </td>
                    <td className="py-2.5 px-3 text-slate-400 whitespace-nowrap">
                      {alert.timestamp}
                    </td>
                    <td className="py-2.5 px-3 text-slate-200 font-medium group-hover:text-cyan-300 max-w-xs truncate">
                      {alert.ruleName}
                    </td>
                    <td className="py-2.5 px-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        alert.severity === 'Critical' ? 'bg-[#3b1219] text-red-300 border border-red-800' :
                        alert.severity === 'High' ? 'bg-[#3b2b0f] text-amber-300 border border-amber-800' :
                        'bg-[#1e3a15] text-lime-300 border border-lime-800'
                      }`}>
                        {alert.severity}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-slate-300">
                      {alert.agent}
                    </td>
                    <td className="py-2.5 px-3 text-slate-300">
                      {alert.sourceIp}
                    </td>
                    <td className="py-2.5 px-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] ${
                        alert.status === 'Resolved' ? 'bg-emerald-950 text-emerald-400' :
                        alert.status === 'Investigating' ? 'bg-amber-950 text-amber-400' :
                        'bg-slate-800 text-slate-300'
                      }`}>
                        {alert.status}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-right">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectAlert(alert);
                        }}
                        className="px-2.5 py-1 rounded bg-[#162030] hover:bg-[#1e2d42] text-cyan-300 border border-cyan-800/60 text-[11px]"
                      >
                        Investigate &rarr;
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
