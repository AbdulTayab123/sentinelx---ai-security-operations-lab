import React, { useState } from 'react';
import { 
  Terminal, 
  Shield, 
  Lock, 
  Key, 
  FileText, 
  Copy, 
  Check, 
  Sliders, 
  AlertTriangle, 
  FolderLock,
  Layers,
  ChevronRight
} from 'lucide-react';

export const LinuxHardeningLab: React.FC = () => {
  const [activeModule, setActiveModule] = useState<'auth_logs' | 'permissions' | 'ssh_config' | 'least_privilege' | 'secure_logging'>('auth_logs');
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  // SSH Config Generator Interactive States
  const [sshPort, setSshPort] = useState('2222');
  const [permitRoot, setPermitRoot] = useState('no');
  const [passwordAuth, setPasswordAuth] = useState('no');
  const [pubkeyAuth, setPubkeyAuth] = useState('yes');
  const [maxAuthTries, setMaxAuthTries] = useState('3');
  const [allowUsers, setAllowUsers] = useState('admin-sec ops-lead');

  // File Permission Interactive Calculator
  const [permUserR, setPermUserR] = useState(true);
  const [permUserW, setPermUserW] = useState(true);
  const [permUserX, setPermUserX] = useState(false);
  const [permGroupR, setPermGroupR] = useState(true);
  const [permGroupW, setPermGroupW] = useState(false);
  const [permGroupX, setPermGroupX] = useState(false);
  const [permOtherR, setPermOtherR] = useState(false);
  const [permOtherW, setPermOtherW] = useState(false);
  const [permOtherX, setPermOtherX] = useState(false);
  const [suidBit, setSuidBit] = useState(false);

  const calcUserOctal = (permUserR ? 4 : 0) + (permUserW ? 2 : 0) + (permUserX ? 1 : 0);
  const calcGroupOctal = (permGroupR ? 4 : 0) + (permGroupW ? 2 : 0) + (permGroupX ? 1 : 0);
  const calcOtherOctal = (permOtherR ? 4 : 0) + (permOtherW ? 2 : 0) + (permOtherX ? 1 : 0);
  const specialOctal = suidBit ? 4 : 0;
  const octalResult = `${specialOctal > 0 ? specialOctal : ''}${calcUserOctal}${calcGroupOctal}${calcOtherOctal}`;

  const handleCopy = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const generatedSshdConfig = `# /etc/ssh/sshd_config — Hardened SentinelX Baseline
Port ${sshPort}
Protocol 2
PermitRootLogin ${permitRoot}
PasswordAuthentication ${passwordAuth}
PubkeyAuthentication ${pubkeyAuth}
MaxAuthTries ${maxAuthTries}
LoginGraceTime 30
AllowUsers ${allowUsers}
X11Forwarding no
MaxSessions 2
ClientAliveInterval 300
ClientAliveCountMax 2
KexAlgorithms curve25519-sha256@libssh.org,diffie-hellman-group-exchange-sha256
Ciphers chacha20-poly1305@openssh.com,aes256-gcm@openssh.com
MACs hmac-sha2-512-etm@openssh.com`;

  return (
    <div className="p-4 space-y-4 font-mono select-none">
      {/* Module Title Banner */}
      <div className="bg-[#111622] border border-[#1b2536] rounded p-4 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center space-x-3">
          <div className="p-2.5 rounded bg-cyan-950/80 text-cyan-400 border border-cyan-800">
            <Terminal className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="text-sm font-bold text-white uppercase tracking-wider">
                Linux Defense & Systems Hardening Lab
              </h2>
              <span className="px-2 py-0.5 rounded bg-cyan-900/60 text-cyan-300 text-[10px] font-bold">
                Defensive Learning Center
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Educational reference for Linux authorization logs, file permissions, SSH hardening, and immutable auditing.
            </p>
          </div>
        </div>

        <div className="text-[11px] text-amber-400/90 flex items-center bg-[#251b0f] border border-amber-900 px-3 py-1.5 rounded">
          <AlertTriangle className="w-3.5 h-3.5 mr-1.5 text-amber-400 shrink-0" />
          <span>Educational text only. Browser execution is intentionally disabled.</span>
        </div>
      </div>

      {/* Module Tabs Navigation */}
      <div className="flex flex-wrap gap-1.5 border-b border-[#1b2536] pb-2 text-xs">
        {[
          { id: 'auth_logs', label: '1. Auth Logs & PAM Analysis', icon: FileText },
          { id: 'ssh_config', label: '2. SSH Hardening Workbench', icon: Lock },
          { id: 'permissions', label: '3. Permissions & SUID Audit', icon: FolderLock },
          { id: 'least_privilege', label: '4. Sudoers & Least Privilege', icon: Key },
          { id: 'secure_logging', label: '5. Immutable Audit & Rsyslog', icon: Layers }
        ].map(tab => {
          const Icon = tab.icon;
          const isActive = activeModule === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveModule(tab.id as any)}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded transition-colors ${
                isActive
                  ? 'bg-cyan-900 text-cyan-200 border border-cyan-600 font-bold'
                  : 'bg-[#121824] text-slate-400 hover:text-slate-200 border border-[#182233]'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Module 1: Auth Logs & PAM Analysis */}
      {activeModule === 'auth_logs' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="bg-[#111622] border border-[#1b2536] p-4 rounded space-y-3">
              <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center">
                <FileText className="w-4 h-4 text-lime-400 mr-2" />
                Debian/Ubuntu vs RHEL Log Paths
              </h3>
              <div className="space-y-2 text-xs text-slate-300">
                <p>
                  • <strong>Debian/Ubuntu:</strong> <code className="text-lime-300">/var/log/auth.log</code> records all SSH logins, sudo executions, PAM authentication attempts, and cron authorizations.
                </p>
                <p>
                  • <strong>RHEL/CentOS/Rocky:</strong> <code className="text-lime-300">/var/log/secure</code> performs the equivalent function.
                </p>
                <p>
                  • <strong>Key daemon identifiers:</strong> <code className="text-cyan-300">sshd</code>, <code className="text-cyan-300">sudo</code>, <code className="text-cyan-300">pam_unix</code>, <code className="text-cyan-300">systemd-logind</code>.
                </p>
              </div>
            </div>

            <div className="bg-[#111622] border border-[#1b2536] p-4 rounded space-y-3">
              <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center">
                <Shield className="w-4 h-4 text-cyan-400 mr-2" />
                Failed vs Malicious Patterns
              </h3>
              <div className="space-y-2 text-xs text-slate-300">
                <div className="p-2 bg-[#090d15] rounded border border-slate-800 text-[11px]">
                  <strong className="text-red-400">Failed password for invalid user:</strong>
                  <div className="text-slate-400 mt-0.5">Indicates attacker testing dictionary words (admin, guest, deploy) that don't exist on host.</div>
                </div>
                <div className="p-2 bg-[#090d15] rounded border border-slate-800 text-[11px]">
                  <strong className="text-amber-400">pam_faillock / pam_tally2 lockouts:</strong>
                  <div className="text-slate-400 mt-0.5">Account locked after N attempts. Check for automated brute force sprays.</div>
                </div>
              </div>
            </div>
          </div>

          {/* Educational Commands */}
          <div className="bg-[#111622] border border-[#1b2536] p-4 rounded space-y-2">
            <h4 className="text-xs font-bold text-slate-200 uppercase">Essential Diagnostic Commands:</h4>
            {[
              { cmd: 'sudo grep "Failed password" /var/log/auth.log | awk "{print $(NF-3)}" | sort | uniq -c | sort -nr | head -10', desc: 'Find top 10 remote IP addresses failing authentication' },
              { cmd: 'sudo grep "Invalid user" /var/log/auth.log | awk "{print $8}" | sort | uniq -c | sort -nr | head -10', desc: 'Find top usernames targeted in credential scans' },
              { cmd: 'sudo grep "COMMAND=" /var/log/auth.log | tail -n 20', desc: 'Audit recent sudo commands executed on the system' }
            ].map((item, idx) => (
              <div key={idx} className="p-2.5 bg-[#090d15] rounded border border-slate-800 flex items-center justify-between gap-3 text-xs">
                <div className="flex-1 overflow-x-auto">
                  <div className="text-[10px] text-slate-400 mb-0.5">{item.desc}</div>
                  <code className="text-lime-300 select-all">{item.cmd}</code>
                </div>
                <button
                  onClick={() => handleCopy(item.cmd, idx)}
                  className="px-2 py-1 rounded bg-[#162030] hover:bg-[#1e2a40] text-slate-300 shrink-0 text-[10px] flex items-center space-x-1"
                >
                  {copiedIndex === idx ? <Check className="w-3 h-3 text-lime-400" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedIndex === idx ? 'Copied' : 'Copy'}</span>
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Module 2: SSH Hardening Workbench */}
      {activeModule === 'ssh_config' && (
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
          {/* Config Builder Controls */}
          <div className="md:col-span-5 bg-[#111622] border border-[#1b2536] p-4 rounded space-y-3">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center">
              <Sliders className="w-4 h-4 text-cyan-400 mr-2" />
              Interactive Hardening Controls
            </h3>

            <div className="space-y-2.5 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">Custom SSH Port (Obscurity / Noise Reduction):</label>
                <input
                  type="text"
                  value={sshPort}
                  onChange={(e) => setSshPort(e.target.value)}
                  className="w-full bg-[#0a0d14] border border-slate-700 rounded px-2.5 py-1 text-slate-200"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">PermitRootLogin:</label>
                <select
                  value={permitRoot}
                  onChange={(e) => setPermitRoot(e.target.value)}
                  className="w-full bg-[#0a0d14] border border-slate-700 rounded px-2.5 py-1 text-slate-200"
                >
                  <option value="no">no (Defensive Standard — Recommended)</option>
                  <option value="prohibit-password">prohibit-password (Keys only)</option>
                  <option value="yes">yes (Insecure Risk)</option>
                </select>
              </div>

              <div>
                <label className="text-slate-400 block mb-1">PasswordAuthentication:</label>
                <select
                  value={passwordAuth}
                  onChange={(e) => setPasswordAuth(e.target.value)}
                  className="w-full bg-[#0a0d14] border border-slate-700 rounded px-2.5 py-1 text-slate-200"
                >
                  <option value="no">no (Enforce ED25519/RSA Public Keys)</option>
                  <option value="yes">yes (Vulnerable to brute force)</option>
                </select>
              </div>

              <div>
                <label className="text-slate-400 block mb-1">MaxAuthTries:</label>
                <input
                  type="number"
                  min="1"
                  max="6"
                  value={maxAuthTries}
                  onChange={(e) => setMaxAuthTries(e.target.value)}
                  className="w-full bg-[#0a0d14] border border-slate-700 rounded px-2.5 py-1 text-slate-200"
                />
              </div>

              <div>
                <label className="text-slate-400 block mb-1">AllowUsers (Whitelist):</label>
                <input
                  type="text"
                  value={allowUsers}
                  onChange={(e) => setAllowUsers(e.target.value)}
                  className="w-full bg-[#0a0d14] border border-slate-700 rounded px-2.5 py-1 text-slate-200"
                />
              </div>
            </div>
          </div>

          {/* Generated File Output */}
          <div className="md:col-span-7 bg-[#111622] border border-[#1b2536] p-4 rounded flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-lime-400 uppercase">
                  Generated /etc/ssh/sshd_config
                </span>
                <button
                  onClick={() => handleCopy(generatedSshdConfig, 999)}
                  className="px-2.5 py-1 rounded bg-[#162030] hover:bg-[#1f2d44] text-slate-200 text-xs flex items-center space-x-1"
                >
                  {copiedIndex === 999 ? <Check className="w-3.5 h-3.5 text-lime-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedIndex === 999 ? 'Copied' : 'Copy Config'}</span>
                </button>
              </div>
              <pre className="p-3 bg-[#080b10] border border-[#162030] rounded text-lime-300 text-[11px] font-mono overflow-x-auto whitespace-pre leading-relaxed max-h-[300px]">
                {generatedSshdConfig}
              </pre>
            </div>

            <div className="mt-3 pt-2 border-t border-[#182030] text-[11px] text-slate-400">
              Safe testing: <code className="text-slate-200">sshd -t</code> tests syntax without interrupting current active sessions.
            </div>
          </div>
        </div>
      )}

      {/* Module 3: Permissions & SUID Audit Calculator */}
      {activeModule === 'permissions' && (
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
          <div className="md:col-span-6 bg-[#111622] border border-[#1b2536] p-4 rounded space-y-4">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center">
              <FolderLock className="w-4 h-4 text-lime-400 mr-2" />
              Interactive Octal Permissions Calculator
            </h3>

            <div className="grid grid-cols-3 gap-3 text-xs bg-[#0b0f16] p-3 rounded border border-slate-800">
              {/* User Permissions */}
              <div className="space-y-1.5">
                <span className="font-bold text-cyan-300 block">User (Owner)</span>
                <label className="flex items-center space-x-1.5 cursor-pointer">
                  <input type="checkbox" checked={permUserR} onChange={(e) => setPermUserR(e.target.checked)} />
                  <span>Read (4)</span>
                </label>
                <label className="flex items-center space-x-1.5 cursor-pointer">
                  <input type="checkbox" checked={permUserW} onChange={(e) => setPermUserW(e.target.checked)} />
                  <span>Write (2)</span>
                </label>
                <label className="flex items-center space-x-1.5 cursor-pointer">
                  <input type="checkbox" checked={permUserX} onChange={(e) => setPermUserX(e.target.checked)} />
                  <span>Execute (1)</span>
                </label>
              </div>

              {/* Group Permissions */}
              <div className="space-y-1.5">
                <span className="font-bold text-amber-300 block">Group</span>
                <label className="flex items-center space-x-1.5 cursor-pointer">
                  <input type="checkbox" checked={permGroupR} onChange={(e) => setPermGroupR(e.target.checked)} />
                  <span>Read (4)</span>
                </label>
                <label className="flex items-center space-x-1.5 cursor-pointer">
                  <input type="checkbox" checked={permGroupW} onChange={(e) => setPermGroupW(e.target.checked)} />
                  <span>Write (2)</span>
                </label>
                <label className="flex items-center space-x-1.5 cursor-pointer">
                  <input type="checkbox" checked={permGroupX} onChange={(e) => setPermGroupX(e.target.checked)} />
                  <span>Execute (1)</span>
                </label>
              </div>

              {/* Other Permissions */}
              <div className="space-y-1.5">
                <span className="font-bold text-red-300 block">Others (World)</span>
                <label className="flex items-center space-x-1.5 cursor-pointer">
                  <input type="checkbox" checked={permOtherR} onChange={(e) => setPermOtherR(e.target.checked)} />
                  <span>Read (4)</span>
                </label>
                <label className="flex items-center space-x-1.5 cursor-pointer">
                  <input type="checkbox" checked={permOtherW} onChange={(e) => setPermOtherW(e.target.checked)} />
                  <span>Write (2)</span>
                </label>
                <label className="flex items-center space-x-1.5 cursor-pointer">
                  <input type="checkbox" checked={permOtherX} onChange={(e) => setPermOtherX(e.target.checked)} />
                  <span>Execute (1)</span>
                </label>
              </div>
            </div>

            <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
              <div>
                <span className="text-[10px] text-slate-400 uppercase block">Octal Mode:</span>
                <span className="text-2xl font-bold text-lime-400 font-mono">chmod {octalResult}</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 uppercase block">Symbolic:</span>
                <span className="text-sm font-bold text-cyan-300 font-mono">
                  {permUserR ? 'r' : '-'}{permUserW ? 'w' : '-'}{permUserX ? 'x' : '-'}
                  {permGroupR ? 'r' : '-'}{permGroupW ? 'w' : '-'}{permGroupX ? 'x' : '-'}
                  {permOtherR ? 'r' : '-'}{permOtherW ? 'w' : '-'}{permOtherX ? 'x' : '-'}
                </span>
              </div>
            </div>
          </div>

          <div className="md:col-span-6 bg-[#111622] border border-[#1b2536] p-4 rounded space-y-3">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center">
              <AlertTriangle className="w-4 h-4 text-amber-400 mr-2" />
              SUID & SGID Privilege Escalation Risks
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Files with SUID (<code className="text-amber-300">chmod 4755</code>) execute with the permissions of the file owner (often <code className="text-red-400">root</code>) rather than the invoking user. Misconfigured binaries (e.g. bash, find, nmap, vim) allow instant local privilege escalation.
            </p>

            <div className="p-2.5 bg-[#080b10] rounded border border-slate-800 text-xs space-y-2">
              <div className="text-[10px] text-slate-400">Audit command to find all SUID binaries on disk:</div>
              <code className="text-lime-300 text-[11px] block select-all">
                find / -perm -4000 -type f 2&gt;/dev/null
              </code>
            </div>

            <div className="p-2.5 bg-[#080b10] rounded border border-slate-800 text-xs space-y-2">
              <div className="text-[10px] text-slate-400">Audit command to locate world-writable files:</div>
              <code className="text-lime-300 text-[11px] block select-all">
                find / -xdev -type d \( -perm -0002 -a ! -perm -1000 \) -print
              </code>
            </div>
          </div>
        </div>
      )}

      {/* Module 4: Least Privilege & Sudoers */}
      {activeModule === 'least_privilege' && (
        <div className="bg-[#111622] border border-[#1b2536] p-4 rounded space-y-3">
          <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center">
            <Key className="w-4 h-4 text-cyan-400 mr-2" />
            Sudoers Hardening & Principle of Least Privilege
          </h3>
          <p className="text-xs text-slate-300">
            Never edit <code className="text-cyan-300">/etc/sudoers</code> directly; always execute <code className="text-lime-300">sudo visudo</code> to prevent syntax locks.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
            <div className="bg-[#090d15] p-3 rounded border border-red-900/60">
              <span className="text-red-400 font-bold block mb-1">Dangerous Sudoers Directive:</span>
              <code className="text-red-300 text-[11px] block">deploy ALL=(ALL) NOPASSWD: ALL</code>
              <p className="text-slate-400 text-[10px] mt-1">If the deploy account's SSH key or API token leaks, attacker gets instant root access without password challenge.</p>
            </div>
            <div className="bg-[#090d15] p-3 rounded border border-emerald-900/60">
              <span className="text-emerald-400 font-bold block mb-1">Restricted Command Scope:</span>
              <code className="text-emerald-300 text-[11px] block">deploy ALL=(root) /bin/systemctl restart nginx</code>
              <p className="text-slate-400 text-[10px] mt-1">Limits user execution to specific binary without wildcard parameters.</p>
            </div>
          </div>
        </div>
      )}

      {/* Module 5: Immutable Audit & Secure Logging */}
      {activeModule === 'secure_logging' && (
        <div className="bg-[#111622] border border-[#1b2536] p-4 rounded space-y-3">
          <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center">
            <Layers className="w-4 h-4 text-lime-400 mr-2" />
            Log Tampering Defense & Immutability
          </h3>
          <p className="text-xs text-slate-300">
            Attacking actors frequently clear logs using <code className="text-red-300">history -c</code> or truncating <code className="text-red-300">/var/log/auth.log</code>.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-2.5 text-xs">
            <div className="bg-[#090d15] p-2.5 rounded border border-slate-800">
              <span className="text-cyan-400 font-bold block mb-1">Append-Only Immutability</span>
              <code className="text-lime-300 text-[10px] block">sudo chattr +a /var/log/auth.log</code>
              <p className="text-slate-400 text-[10px] mt-1">Prevents deletion or truncation even by root.</p>
            </div>
            <div className="bg-[#090d15] p-2.5 rounded border border-slate-800">
              <span className="text-cyan-400 font-bold block mb-1">Centralized Rsyslog Push</span>
              <code className="text-lime-300 text-[10px] block">*.* @@siem.corp.internal:514</code>
              <p className="text-slate-400 text-[10px] mt-1">Streams logs off-box in real-time via TLS.</p>
            </div>
            <div className="bg-[#090d15] p-2.5 rounded border border-slate-800">
              <span className="text-cyan-400 font-bold block mb-1">Auditd Kernel Rules</span>
              <code className="text-lime-300 text-[10px] block">-w /etc/passwd -p wa -k identity</code>
              <p className="text-slate-400 text-[10px] mt-1">Tracks write/attribute changes at Linux kernel layer.</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
