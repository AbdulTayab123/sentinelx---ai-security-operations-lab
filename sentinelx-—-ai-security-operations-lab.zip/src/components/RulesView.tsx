import React, { useState } from 'react';
import { ShieldCheck, Plus, RotateCcw, AlertTriangle, Check, Trash2, Edit2, Play } from 'lucide-react';
import { DetectionRule, Severity } from '../types/security';

interface RulesViewProps {
  rules: DetectionRule[];
  onToggleRule: (id: string) => void;
  onAddRule: (rule: Omit<DetectionRule, 'id' | 'matchedCount'>) => void;
  onDeleteRule: (id: string) => void;
  onResetRules: () => void;
}

export const RulesView: React.FC<RulesViewProps> = ({
  rules,
  onToggleRule,
  onAddRule,
  onDeleteRule,
  onResetRules
}) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [newRuleName, setNewRuleName] = useState('');
  const [newRuleDesc, setNewRuleDesc] = useState('');
  const [newRuleSeverity, setNewRuleSeverity] = useState<Severity>('High');
  const [newRuleCondition, setNewRuleCondition] = useState<DetectionRule['conditionType']>('failed_login_threshold');
  const [newRuleThreshold, setNewRuleThreshold] = useState<number>(5);
  const [newRulePattern, setNewRulePattern] = useState('');
  const [newRulePlaybook, setNewRulePlaybook] = useState('Block source IP and verify credentials.');

  const handleSubmitNewRule = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRuleName.trim()) return;

    onAddRule({
      name: newRuleName,
      description: newRuleDesc || 'Custom defensive rule',
      severity: newRuleSeverity,
      enabled: true,
      category: 'Authentication',
      conditionType: newRuleCondition,
      threshold: newRuleThreshold,
      windowSeconds: 60,
      pattern: newRulePattern,
      mitreId: 'T1110',
      mitreTactic: 'Credential Access',
      playbook: newRulePlaybook
    });

    // Reset form
    setNewRuleName('');
    setNewRuleDesc('');
    setNewRulePattern('');
    setShowAddModal(false);
  };

  return (
    <div className="p-4 space-y-4 font-mono select-none">
      {/* Header bar */}
      <div className="bg-[#111622] border border-[#1b2536] rounded p-4 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center space-x-3">
          <div className="p-2.5 rounded bg-lime-950/80 text-lime-400 border border-lime-800">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="text-sm font-bold text-white uppercase tracking-wider">
                Detection Rule Engine & Signatures
              </h2>
              <span className="px-2 py-0.5 rounded bg-lime-900/60 text-lime-300 text-[10px] font-bold">
                {rules.filter(r => r.enabled).length}/{rules.length} Active
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Configurable behavioral heuristics and regex patterns evaluating ingested log streams.
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={onResetRules}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded bg-[#162030] hover:bg-[#1f2d44] text-slate-300 border border-slate-700 text-xs transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5 text-amber-400" />
            <span>Reset to Defaults</span>
          </button>
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded bg-lime-900/60 hover:bg-lime-800/80 text-lime-300 border border-lime-700 text-xs font-bold transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Create Rule</span>
          </button>
        </div>
      </div>

      {/* Rules list */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {rules.map((rule) => (
          <div
            key={rule.id}
            className={`p-4 rounded border transition-colors flex flex-col justify-between ${
              rule.enabled
                ? 'bg-[#111622] border-[#1b2536]'
                : 'bg-[#0a0d14] border-slate-800 opacity-60'
            }`}
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center space-x-2">
                  <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-800 text-slate-300 font-bold">
                    {rule.id}
                  </span>
                  <span className={`text-[10px] px-2 py-0.5 rounded font-bold ${
                    rule.severity === 'Critical' ? 'bg-red-950 text-red-300 border border-red-800' :
                    rule.severity === 'High' ? 'bg-amber-950 text-amber-300 border border-amber-800' :
                    'bg-lime-950 text-lime-300 border border-lime-800'
                  }`}>
                    {rule.severity}
                  </span>
                  <span className="text-[10px] text-cyan-400">
                    MITRE: {rule.mitreId}
                  </span>
                </div>

                <div className="flex items-center space-x-2">
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={rule.enabled}
                      onChange={() => onToggleRule(rule.id)}
                      className="sr-only peer"
                    />
                    <div className="w-8 h-4 bg-slate-850 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3 after:w-3 after:transition-all peer-checked:bg-lime-500"></div>
                  </label>
                  <button
                    onClick={() => onDeleteRule(rule.id)}
                    title="Delete rule"
                    className="p-1 text-slate-500 hover:text-red-400 transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <h3 className="text-xs font-bold text-white mb-1">
                {rule.name}
              </h3>
              <p className="text-[11px] text-slate-400 leading-relaxed mb-3">
                {rule.description}
              </p>

              {rule.pattern && (
                <div className="p-2 bg-[#080b10] rounded border border-slate-800 mb-2">
                  <span className="text-[9px] text-slate-500 uppercase block">Pattern:</span>
                  <code className="text-lime-400 text-[10px] break-all">{rule.pattern}</code>
                </div>
              )}

              {rule.threshold && (
                <div className="text-[10px] text-slate-400 mb-2">
                  Threshold: <strong className="text-white">{rule.threshold} events</strong> in window {rule.windowSeconds || 60}s
                </div>
              )}
            </div>

            <div className="pt-2 border-t border-[#182030] flex items-center justify-between text-[10px] text-slate-500">
              <span>Triggered: <strong className="text-lime-400">{rule.matchedCount} times</strong></span>
              <span className="text-slate-400 max-w-[200px] truncate">{rule.playbook}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Create Rule Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
          <form
            onSubmit={handleSubmitNewRule}
            className="bg-[#111622] border border-[#1e2a3c] rounded-lg max-w-lg w-full p-4 space-y-3 text-xs"
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="font-bold text-white uppercase">Define New Safe Detection Rule</span>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Rule Name:</label>
              <input
                type="text"
                required
                placeholder="e.g. Malformed SQLi Probe in Web Access"
                value={newRuleName}
                onChange={(e) => setNewRuleName(e.target.value)}
                className="w-full bg-[#0a0d14] border border-slate-700 rounded px-2.5 py-1.5 text-slate-200"
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Severity:</label>
              <select
                value={newRuleSeverity}
                onChange={(e) => setNewRuleSeverity(e.target.value as Severity)}
                className="w-full bg-[#0a0d14] border border-slate-700 rounded px-2.5 py-1.5 text-slate-200"
              >
                <option value="Critical">Critical</option>
                <option value="High">High</option>
                <option value="Medium">Medium</option>
                <option value="Low">Low</option>
              </select>
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Condition Type:</label>
              <select
                value={newRuleCondition}
                onChange={(e) => setNewRuleCondition(e.target.value as any)}
                className="w-full bg-[#0a0d14] border border-slate-700 rounded px-2.5 py-1.5 text-slate-200"
              >
                <option value="failed_login_threshold">Failed Login Threshold</option>
                <option value="regex_pattern">Regular Expression / Substring Pattern</option>
                <option value="sudo_violation">Unauthorized Sudo Execution</option>
              </select>
            </div>

            {newRuleCondition === 'regex_pattern' && (
              <div>
                <label className="text-slate-400 block mb-1">Regex Pattern:</label>
                <input
                  type="text"
                  placeholder="e.g. (UNION\s+SELECT|<script|etc/passwd)"
                  value={newRulePattern}
                  onChange={(e) => setNewRulePattern(e.target.value)}
                  className="w-full bg-[#0a0d14] border border-slate-700 rounded px-2.5 py-1.5 text-slate-200"
                />
              </div>
            )}

            {newRuleCondition === 'failed_login_threshold' && (
              <div>
                <label className="text-slate-400 block mb-1">Threshold Failures (Count):</label>
                <input
                  type="number"
                  min="1"
                  max="50"
                  value={newRuleThreshold}
                  onChange={(e) => setNewRuleThreshold(parseInt(e.target.value, 10))}
                  className="w-full bg-[#0a0d14] border border-slate-700 rounded px-2.5 py-1.5 text-slate-200"
                />
              </div>
            )}

            <div>
              <label className="text-slate-400 block mb-1">Defensive Playbook / Action:</label>
              <input
                type="text"
                value={newRulePlaybook}
                onChange={(e) => setNewRulePlaybook(e.target.value)}
                className="w-full bg-[#0a0d14] border border-slate-700 rounded px-2.5 py-1.5 text-slate-200"
              />
            </div>

            <div className="flex justify-end space-x-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="px-3 py-1.5 rounded bg-slate-800 text-slate-300"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-3 py-1.5 rounded bg-lime-600 text-black font-bold hover:bg-lime-500"
              >
                Save Rule
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
