import React, { useState } from 'react';
import { 
  X, 
  ShieldAlert, 
  Terminal, 
  Copy, 
  Check, 
  Download, 
  ExternalLink, 
  Sparkles, 
  MapPin, 
  Server, 
  Clock, 
  CheckCircle2 
} from 'lucide-react';
import { Alert } from '../types/security';

interface IncidentDetailModalProps {
  alert: Alert | null;
  onClose: () => void;
  onUpdateStatus?: (alertId: string, newStatus: Alert['status']) => void;
}

export const IncidentDetailModal: React.FC<IncidentDetailModalProps> = ({
  alert,
  onClose,
  onUpdateStatus
}) => {
  const [copied, setCopied] = useState(false);
  const [aiAnalysis, setAiAnalysis] = useState<string | null>(null);
  const [isGeneratingAi, setIsGeneratingAi] = useState(false);

  if (!alert) return null;

  const handleCopyLog = () => {
    if (alert.rawLog) {
      navigator.clipboard.writeText(alert.rawLog);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleExportJson = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(alert, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `incident-${alert.id}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const runAiTriage = () => {
    setIsGeneratingAi(true);
    setTimeout(() => {
      setAiAnalysis(
        `AI Triage Assessment:
• Severity Justification: High confidence threat matching MITRE ${alert.mitreTechniqueId || 'T1110'}.
• Threat Origin: ${alert.sourceIp} (${alert.location || 'External Subnet'}).
• Assessment: Active automated brute force or credential spray targeting SSH daemon.
• Recommended SOC Action:
  1. Add source IP to firewall drop table: iptables -I INPUT -s ${alert.sourceIp} -j DROP
  2. Verify if user '${alert.user || 'admin'}' has compromised keys.
  3. Ensure SSH password authentication is disabled in /etc/ssh/sshd_config.`
      );
      setIsGeneratingAi(false);
    }, 700);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-[#111622] border border-[#1e2a3c] rounded-lg max-w-3xl w-full max-h-[90vh] overflow-y-auto shadow-2xl flex flex-col font-sans">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-[#1b2536] bg-[#0c1017]">
          <div className="flex items-center space-x-3">
            <div className={`p-2 rounded ${
              alert.severity === 'Critical' ? 'bg-red-950/80 text-red-400 border border-red-800' :
              alert.severity === 'High' ? 'bg-amber-950/80 text-amber-400 border border-amber-800' :
              'bg-lime-950/80 text-lime-400 border border-lime-800'
            }`}>
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-xs font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-bold">
                  {alert.id}
                </span>
                <span className={`text-xs font-mono font-bold px-2 py-0.5 rounded ${
                  alert.severity === 'Critical' ? 'bg-red-900/60 text-red-200' :
                  alert.severity === 'High' ? 'bg-amber-900/60 text-amber-200' :
                  'bg-lime-900/60 text-lime-200'
                }`}>
                  {alert.severity}
                </span>
                <span className="text-xs text-slate-400 font-mono flex items-center">
                  <Clock className="w-3 h-3 mr-1" />
                  {alert.timestamp}
                </span>
              </div>
              <h2 className="text-sm font-semibold text-white mt-1 font-mono">
                {alert.ruleName}
              </h2>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded hover:bg-[#1a2333] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 space-y-4 text-xs font-mono text-slate-300">
          {/* Metadata Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5 p-3 rounded bg-[#0b0f16] border border-[#162030]">
            <div>
              <span className="text-[10px] text-slate-500 uppercase block">Source IP</span>
              <span className="text-white font-semibold flex items-center mt-0.5">
                {alert.sourceIp}
              </span>
              <span className="text-[10px] text-slate-400 flex items-center mt-0.5">
                <MapPin className="w-3 h-3 mr-1 text-slate-500" />
                {alert.location || 'Unknown GeoIP'}
              </span>
            </div>

            <div>
              <span className="text-[10px] text-slate-500 uppercase block">Target Host</span>
              <span className="text-white font-semibold flex items-center mt-0.5">
                <Server className="w-3 h-3 mr-1 text-slate-400" />
                {alert.agent}
              </span>
              <span className="text-[10px] text-slate-400 mt-0.5 block">
                Dest: {alert.destIp}
              </span>
            </div>

            <div>
              <span className="text-[10px] text-slate-500 uppercase block">Target Port / User</span>
              <span className="text-white font-semibold mt-0.5 block">
                Port: {alert.port || 22}
              </span>
              <span className="text-[10px] text-slate-400 mt-0.5 block">
                User: {alert.user || 'root/invalid'}
              </span>
            </div>

            <div>
              <span className="text-[10px] text-slate-500 uppercase block">MITRE ATT&CK</span>
              <span className="text-cyan-400 font-semibold mt-0.5 block">
                {alert.mitreTechniqueId || 'T1110.001'}
              </span>
              <span className="text-[10px] text-slate-400 mt-0.5 block">
                {alert.mitreTactic || 'Credential Access'}
              </span>
            </div>
          </div>

          {/* Description */}
          <div>
            <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider mb-1">
              Detection Reason & Analysis
            </h3>
            <p className="p-3 bg-[#0d121c] rounded border border-[#172233] text-slate-300 leading-relaxed">
              {alert.description}
            </p>
          </div>

          {/* Raw Log */}
          {alert.rawLog && (
            <div>
              <div className="flex items-center justify-between mb-1">
                <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center">
                  <Terminal className="w-3.5 h-3.5 mr-1.5 text-lime-400" />
                  Raw Security Log Extract
                </h3>
                <button
                  onClick={handleCopyLog}
                  className="flex items-center space-x-1 text-[11px] text-slate-400 hover:text-slate-200"
                >
                  {copied ? <Check className="w-3 h-3 text-lime-400" /> : <Copy className="w-3 h-3" />}
                  <span>{copied ? 'Copied!' : 'Copy line'}</span>
                </button>
              </div>
              <pre className="p-3 bg-[#080b10] border border-[#162030] rounded text-lime-400 text-[11px] font-mono overflow-x-auto whitespace-pre-wrap selection:bg-lime-900">
                {alert.rawLog}
              </pre>
            </div>
          )}

          {/* Recommended Defensive Actions */}
          <div>
            <h3 className="text-xs font-bold text-cyan-400 uppercase tracking-wider mb-1">
              Recommended Defensive Actions & Playbook
            </h3>
            <div className="p-3 bg-[#0c1322] border border-[#162942] rounded space-y-2">
              <p className="text-slate-300">{alert.recommendation}</p>
              <div className="p-2 bg-[#060a12] border border-[#142033] rounded text-slate-300 text-[11px]">
                <div className="text-[10px] text-slate-500 uppercase mb-1">Copy-paste remediation command (Run on host):</div>
                <code className="text-amber-300 select-all">
                  sudo iptables -A INPUT -s {alert.sourceIp} -j DROP && sudo fail2ban-client set sshd banip {alert.sourceIp}
                </code>
              </div>
            </div>
          </div>

          {/* AI Security Co-Pilot Analysis */}
          <div className="p-3 bg-gradient-to-r from-[#101826] to-[#121c30] border border-cyan-900/60 rounded">
            <div className="flex items-center justify-between mb-2">
              <span className="flex items-center space-x-1.5 text-cyan-300 font-bold">
                <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                <span>AI Security Co-Pilot Triage</span>
              </span>
              <button
                onClick={runAiTriage}
                disabled={isGeneratingAi}
                className="px-2.5 py-1 rounded bg-cyan-950 hover:bg-cyan-900 text-cyan-300 border border-cyan-700 text-[11px] transition-colors"
              >
                {isGeneratingAi ? 'Analyzing...' : aiAnalysis ? 'Re-run Analysis' : 'Run AI Triage'}
              </button>
            </div>
            {aiAnalysis ? (
              <pre className="text-slate-300 whitespace-pre-wrap text-[11px] bg-[#090d15] p-2.5 rounded border border-slate-800">
                {aiAnalysis}
              </pre>
            ) : (
              <p className="text-slate-400 text-[11px]">
                Click "Run AI Triage" to execute heuristic and contextual root-cause analysis on this event.
              </p>
            )}
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-[#1b2536] bg-[#0c1017] flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <button
              onClick={handleExportJson}
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded bg-[#162030] hover:bg-[#1e2c42] text-slate-200 border border-slate-700 text-xs font-mono"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export JSON</span>
            </button>
          </div>

          <div className="flex items-center space-x-2">
            {onUpdateStatus && (
              <>
                <button
                  onClick={() => {
                    onUpdateStatus(alert.id, 'Investigating');
                    onClose();
                  }}
                  className="px-3 py-1.5 rounded bg-amber-950/80 hover:bg-amber-900 text-amber-200 border border-amber-800 text-xs font-mono"
                >
                  Mark Investigating
                </button>
                <button
                  onClick={() => {
                    onUpdateStatus(alert.id, 'Resolved');
                    onClose();
                  }}
                  className="px-3 py-1.5 rounded bg-emerald-950/80 hover:bg-emerald-900 text-emerald-200 border border-emerald-800 text-xs font-mono flex items-center space-x-1"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Resolve Incident</span>
                </button>
              </>
            )}
            <button
              onClick={onClose}
              className="px-4 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-white text-xs font-mono"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
