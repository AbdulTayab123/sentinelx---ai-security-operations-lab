import React from 'react';
import { 
  Home, 
  AlertTriangle, 
  FileText, 
  Server, 
  Sliders, 
  ShieldCheck, 
  Activity, 
  Terminal, 
  UploadCloud, 
  ChevronsRight, 
  ChevronsLeft 
} from 'lucide-react';

export type NavTab = 
  | 'overview' 
  | 'alerts' 
  | 'events' 
  | 'agents' 
  | 'config' 
  | 'rules' 
  | 'ml_anomaly' 
  | 'linux_hardening' 
  | 'ingestion';

interface SocSidebarProps {
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  collapsed: boolean;
  onToggleCollapse: () => void;
  alertBadgeCount?: number;
}

export const SocSidebar: React.FC<SocSidebarProps> = ({
  activeTab,
  onSelectTab,
  collapsed,
  onToggleCollapse,
  alertBadgeCount = 147
}) => {
  const navItems: Array<{
    id: NavTab;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    badge?: string | number;
    badgeColor?: string;
  }> = [
    { id: 'overview', label: 'Overview', icon: Home },
    { id: 'alerts', label: 'Alerts', icon: AlertTriangle, badge: alertBadgeCount, badgeColor: 'bg-red-950 text-red-400 border-red-800' },
    { id: 'events', label: 'Events', icon: FileText },
    { id: 'agents', label: 'Agents', icon: Server, badge: 489, badgeColor: 'bg-slate-800 text-slate-300 border-slate-700' },
    { id: 'config', label: 'Config', icon: Sliders },
    { id: 'rules', label: 'Rules', icon: ShieldCheck },
    { id: 'ml_anomaly', label: 'ML Anomaly', icon: Activity },
    { id: 'linux_hardening', label: 'Linux Lab', icon: Terminal },
    { id: 'ingestion', label: 'Ingest Logs', icon: UploadCloud }
  ];

  return (
    <aside
      className={`bg-[#0d1117] border-r border-[#19212f] flex flex-col justify-between transition-all duration-200 select-none z-20 ${
        collapsed ? 'w-14' : 'w-20'
      }`}
    >
      <div className="flex flex-col py-2 space-y-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;

          return (
            <button
              key={item.id}
              onClick={() => onSelectTab(item.id)}
              title={item.label}
              className={`relative flex flex-col items-center justify-center py-2 px-1 transition-all group ${
                isActive
                  ? 'text-cyan-400 bg-[#162030]'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-[#121824]'
              }`}
            >
              {/* Active left indicator matching screenshot */}
              {isActive && (
                <span className="absolute left-0 top-1 bottom-1 w-0.5 bg-cyan-400 rounded-r" />
              )}

              <div className="relative">
                <Icon
                  className={`w-4 h-4 mb-1 transition-transform group-hover:scale-110 ${
                    isActive ? 'text-cyan-400' : 'text-slate-400'
                  }`}
                />
                {item.badge && collapsed && (
                  <span className="absolute -top-1.5 -right-2 w-2 h-2 rounded-full bg-red-500" />
                )}
              </div>

              <span
                className={`text-[9px] tracking-tight text-center leading-tight transition-colors ${
                  isActive ? 'font-semibold text-cyan-300' : 'text-slate-400 group-hover:text-slate-200'
                }`}
              >
                {item.label}
              </span>
            </button>
          );
        })}
      </div>

      {/* Collapse toggle >> at bottom matching screenshot */}
      <div className="p-2 border-t border-[#19212f] flex justify-center">
        <button
          onClick={onToggleCollapse}
          title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          className="text-slate-500 hover:text-slate-300 p-1.5 rounded hover:bg-[#162030] transition-colors"
        >
          {collapsed ? (
            <ChevronsRight className="w-4 h-4" />
          ) : (
            <ChevronsLeft className="w-4 h-4" />
          )}
        </button>
      </div>
    </aside>
  );
};
