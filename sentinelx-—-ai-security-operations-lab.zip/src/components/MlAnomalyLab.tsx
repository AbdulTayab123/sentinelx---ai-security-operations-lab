import React, { useState, useMemo } from 'react';
import { Activity, Sliders, ShieldCheck, AlertCircle, Info, RefreshCw, BarChart2, CheckCircle2 } from 'lucide-react';
import { NetworkFlowDataPoint } from '../types/security';
import { runIsolationForestAnomalyDetection } from '../services/anomalyDetector';
import { SAMPLE_NETWORK_FLOW_CSV } from '../services/sampleData';
import { parseNetworkFlowCsv } from '../services/logParser';

export const MlAnomalyLab: React.FC = () => {
  const [rawCsvText, setRawCsvText] = useState(SAMPLE_NETWORK_FLOW_CSV);
  const [anomalyThreshold, setAnomalyThreshold] = useState<number>(0.65);
  const [selectedPoint, setSelectedPoint] = useState<NetworkFlowDataPoint | null>(null);

  // Parse CSV
  const parsedData = useMemo(() => {
    const { data } = parseNetworkFlowCsv(rawCsvText);
    return data;
  }, [rawCsvText]);

  // Run Isolation Forest ML detection
  const { evaluatedData, evaluation } = useMemo(() => {
    return runIsolationForestAnomalyDetection(parsedData, anomalyThreshold);
  }, [parsedData, anomalyThreshold]);

  const anomalyCount = evaluatedData.filter(d => d.isAnomaly).length;

  return (
    <div className="p-4 space-y-4 font-mono select-none">
      {/* Top Banner explaining the ML Model */}
      <div className="bg-[#111622] border border-[#1b2536] rounded p-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded bg-lime-950/80 text-lime-400 border border-lime-800">
              <Activity className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-sm font-bold text-white uppercase tracking-wider">
                  Isolation Forest ML Anomaly Lab
                </h2>
                <span className="px-1.5 py-0.5 rounded bg-lime-900/60 text-lime-300 text-[10px] font-bold">
                  Unsupervised + Supervised Evaluation
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Evaluates multi-dimensional network flow vectors: <code className="text-slate-300">duration</code>, <code className="text-slate-300">src_bytes</code>, <code className="text-slate-300">dst_bytes</code>, <code className="text-slate-300">packet_rate</code>, <code className="text-slate-300">error_rate</code>.
              </p>
            </div>
          </div>

          <button
            onClick={() => setRawCsvText(SAMPLE_NETWORK_FLOW_CSV)}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded bg-[#162030] hover:bg-[#1f2d44] text-slate-200 border border-slate-700 text-xs"
          >
            <RefreshCw className="w-3.5 h-3.5 text-cyan-400" />
            <span>Reset Evaluation Set</span>
          </button>
        </div>

        {/* Real-time Threshold Slider */}
        <div className="mt-4 pt-3 border-t border-[#1a2333] flex flex-wrap items-center justify-between gap-4 bg-[#0c1018] p-3 rounded">
          <div className="flex items-center space-x-3 flex-1 min-w-[260px]">
            <Sliders className="w-4 h-4 text-cyan-400" />
            <div className="flex-1">
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-300 font-semibold">Decision Boundary Threshold:</span>
                <span className="text-lime-400 font-bold">{anomalyThreshold.toFixed(2)}</span>
              </div>
              <input
                type="range"
                min="0.30"
                max="0.85"
                step="0.01"
                value={anomalyThreshold}
                onChange={(e) => setAnomalyThreshold(parseFloat(e.target.value))}
                className="w-full accent-lime-400 cursor-pointer h-1.5 bg-slate-800 rounded"
              />
            </div>
          </div>

          <div className="flex items-center space-x-4 text-xs">
            <div className="text-slate-400">
              Evaluated Flows: <span className="text-white font-bold">{evaluatedData.length}</span>
            </div>
            <div className="text-slate-400">
              Flagged Outliers: <span className="text-red-400 font-bold">{anomalyCount}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Model Evaluation Metrics & Confusion Matrix */}
      {evaluation && (
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
          {/* Key Metrics Cards */}
          <div className="md:col-span-6 grid grid-cols-2 gap-2.5">
            <div className="bg-[#111622] border border-[#1b2536] p-3 rounded">
              <span className="text-[10px] text-slate-500 uppercase block">Model Precision</span>
              <span className="text-xl font-bold text-lime-400 font-mono">
                {(evaluation.precision * 100).toFixed(1)}%
              </span>
              <span className="text-[10px] text-slate-400 block mt-1">
                TP / (TP + FP) — True attack precision
              </span>
            </div>

            <div className="bg-[#111622] border border-[#1b2536] p-3 rounded">
              <span className="text-[10px] text-slate-500 uppercase block">Recall (Sensitivity)</span>
              <span className="text-xl font-bold text-cyan-400 font-mono">
                {(evaluation.recall * 100).toFixed(1)}%
              </span>
              <span className="text-[10px] text-slate-400 block mt-1">
                TP / (TP + FN) — Intrusion catch rate
              </span>
            </div>

            <div className="bg-[#111622] border border-[#1b2536] p-3 rounded">
              <span className="text-[10px] text-slate-500 uppercase block">F1-Score</span>
              <span className="text-xl font-bold text-emerald-400 font-mono">
                {(evaluation.f1Score * 100).toFixed(1)}%
              </span>
              <span className="text-[10px] text-slate-400 block mt-1">
                Harmonic mean of precision & recall
              </span>
            </div>

            <div className="bg-[#111622] border border-[#1b2536] p-3 rounded">
              <span className="text-[10px] text-slate-500 uppercase block">False Positive Rate (FPR)</span>
              <span className="text-xl font-bold text-amber-400 font-mono">
                {(evaluation.falsePositiveRate * 100).toFixed(1)}%
              </span>
              <span className="text-[10px] text-slate-400 block mt-1">
                FP / (FP + TN) — Benign flagged as attack
              </span>
            </div>
          </div>

          {/* 2x2 Confusion Matrix Card */}
          <div className="md:col-span-6 bg-[#111622] border border-[#1b2536] p-3 rounded flex flex-col justify-between">
            <div className="flex items-center justify-between border-b border-[#182030] pb-1.5 mb-2">
              <span className="text-xs font-bold text-slate-200">CONFUSION MATRIX</span>
              <span className="text-[10px] text-slate-400 font-mono">
                N={evaluation.totalEvaluated} Labeled Flows
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-center my-auto">
              <div className="bg-[#0b1712] border border-emerald-800/80 p-2.5 rounded">
                <span className="text-[10px] text-emerald-400 uppercase font-bold block">True Positive (TP)</span>
                <span className="text-2xl font-bold text-emerald-200 font-mono">
                  {evaluation.confusionMatrix.tp}
                </span>
                <span className="text-[10px] text-emerald-500/80 block">Attacks correctly caught</span>
              </div>

              <div className="bg-[#241315] border border-amber-800/80 p-2.5 rounded">
                <span className="text-[10px] text-amber-400 uppercase font-bold block">False Positive (FP)</span>
                <span className="text-2xl font-bold text-amber-200 font-mono">
                  {evaluation.confusionMatrix.fp}
                </span>
                <span className="text-[10px] text-amber-500/80 block">Normal flows alerted</span>
              </div>

              <div className="bg-[#241315] border border-red-800/80 p-2.5 rounded">
                <span className="text-[10px] text-red-400 uppercase font-bold block">False Negative (FN)</span>
                <span className="text-2xl font-bold text-red-200 font-mono">
                  {evaluation.confusionMatrix.fn}
                </span>
                <span className="text-[10px] text-red-500/80 block">Attacks missed</span>
              </div>

              <div className="bg-[#0c1424] border border-blue-800/80 p-2.5 rounded">
                <span className="text-[10px] text-blue-400 uppercase font-bold block">True Negative (TN)</span>
                <span className="text-2xl font-bold text-blue-200 font-mono">
                  {evaluation.confusionMatrix.tn}
                </span>
                <span className="text-[10px] text-blue-500/80 block">Normal traffic cleared</span>
              </div>
            </div>

            <div className="text-[10px] text-slate-500 text-center pt-2 border-t border-[#182030]">
              Overall Accuracy: <strong className="text-slate-300">{(evaluation.accuracy * 100).toFixed(1)}%</strong>
            </div>
          </div>
        </div>
      )}

      {/* Evaluated Flows Table */}
      <div className="bg-[#111622] border border-[#1b2536] rounded overflow-hidden shadow-sm">
        <div className="p-3 border-b border-[#1b2536] flex items-center justify-between">
          <span className="text-xs font-bold text-slate-200">
            NETWORK FLOW ANOMALY SCORING STREAM
          </span>
          <span className="text-[10px] text-slate-400">
            Score &gt; {anomalyThreshold} = Alert Triggered
          </span>
        </div>

        <div className="overflow-x-auto max-h-[360px]">
          <table className="w-full text-left text-xs">
            <thead className="sticky top-0 bg-[#0c1018] text-slate-400 border-b border-[#1b2536] text-[10px]">
              <tr>
                <th className="py-2 px-2.5">Flow ID</th>
                <th className="py-2 px-2.5">Protocol</th>
                <th className="py-2 px-2.5">Duration (s)</th>
                <th className="py-2 px-2.5">Src Bytes</th>
                <th className="py-2 px-2.5">Packet Rate</th>
                <th className="py-2 px-2.5">Error Rate</th>
                <th className="py-2 px-2.5">Ground Truth</th>
                <th className="py-2 px-2.5">Anomaly Score</th>
                <th className="py-2 px-2.5">Classification</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#172030]">
              {evaluatedData.map((dp) => (
                <tr
                  key={dp.id}
                  onClick={() => setSelectedPoint(dp)}
                  className={`hover:bg-[#161f2e] cursor-pointer transition-colors ${
                    dp.isAnomaly ? 'bg-red-950/20' : ''
                  }`}
                >
                  <td className="py-2 px-2.5 text-slate-300 font-bold">{dp.id}</td>
                  <td className="py-2 px-2.5 text-slate-400">{dp.protocol}</td>
                  <td className="py-2 px-2.5 text-slate-300">{dp.duration}s</td>
                  <td className="py-2 px-2.5 text-slate-300">
                    {dp.srcBytes > 100000 ? `${(dp.srcBytes / 1024 / 1024).toFixed(2)} MB` : `${dp.srcBytes} B`}
                  </td>
                  <td className="py-2 px-2.5 text-slate-300">{dp.packetRate} p/s</td>
                  <td className="py-2 px-2.5 text-slate-300">{(dp.errorRate * 100).toFixed(0)}%</td>
                  <td className="py-2 px-2.5">
                    {dp.groundTruthLabel === 1 ? (
                      <span className="text-red-400 font-bold">1 (Attack)</span>
                    ) : dp.groundTruthLabel === 0 ? (
                      <span className="text-emerald-400">0 (Normal)</span>
                    ) : (
                      <span className="text-slate-500">Unlabeled</span>
                    )}
                  </td>
                  <td className="py-2 px-2.5">
                    <div className="flex items-center space-x-1.5">
                      <div className="w-16 h-2 bg-slate-800 rounded overflow-hidden">
                        <div
                          className={`h-full ${dp.isAnomaly ? 'bg-red-500' : 'bg-lime-500'}`}
                          style={{ width: `${Math.min(100, dp.anomalyScore * 100)}%` }}
                        />
                      </div>
                      <span className={`font-bold ${dp.isAnomaly ? 'text-red-400' : 'text-slate-300'}`}>
                        {dp.anomalyScore.toFixed(2)}
                      </span>
                    </div>
                  </td>
                  <td className="py-2 px-2.5">
                    {dp.isAnomaly ? (
                      <span className="px-2 py-0.5 rounded text-[10px] bg-red-900/60 text-red-200 font-bold border border-red-700/60">
                        ANOMALOUS
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800">
                        BENIGN
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Selected Point Explanation Modal / Drawer */}
      {selectedPoint && (
        <div className="bg-[#111622] border border-cyan-800/80 p-3.5 rounded text-xs">
          <div className="flex items-center justify-between mb-2">
            <span className="font-bold text-white flex items-center">
              <Info className="w-4 h-4 text-cyan-400 mr-1.5" />
              Inspection for Flow Record: {selectedPoint.id}
            </span>
            <button
              onClick={() => setSelectedPoint(null)}
              className="text-slate-400 hover:text-white"
            >
              ✕
            </button>
          </div>
          <p className="text-slate-300">
            <strong>Isolation Forest Path Length Assessment:</strong> {selectedPoint.flaggedReason}
          </p>
          <div className="grid grid-cols-4 gap-2 mt-2 pt-2 border-t border-slate-800 text-[11px] text-slate-400">
            <div>Duration: <span className="text-white">{selectedPoint.duration}s</span></div>
            <div>Src Bytes: <span className="text-white">{selectedPoint.srcBytes}</span></div>
            <div>Packet Rate: <span className="text-white">{selectedPoint.packetRate}</span></div>
            <div>Anomaly Score: <span className="text-lime-400 font-bold">{selectedPoint.anomalyScore}</span></div>
          </div>
        </div>
      )}
    </div>
  );
};
