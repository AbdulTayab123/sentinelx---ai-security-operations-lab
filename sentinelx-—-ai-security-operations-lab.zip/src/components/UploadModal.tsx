import React, { useState } from 'react';
import { X, Upload, FileText, CheckCircle2, AlertCircle, Database, Trash2, ArrowRight } from 'lucide-react';
import { SAMPLE_AUTH_LOG, SAMPLE_NETWORK_FLOW_CSV, SAMPLE_SYSLOG } from '../services/sampleData';
import { parseLinuxAuthLog, parseNetworkFlowCsv } from '../services/logParser';
import { EventLog, Alert } from '../types/security';

interface UploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onIngestLogs: (logs: EventLog[], sourceName: string) => void;
  onIngestFlowCsv: (csvContent: string) => void;
}

export const UploadModal: React.FC<UploadModalProps> = ({
  isOpen,
  onClose,
  onIngestLogs,
  onIngestFlowCsv
}) => {
  const [activeTab, setActiveTab] = useState<'upload' | 'samples'>('samples');
  const [pastedText, setPastedText] = useState('');
  const [selectedFileType, setSelectedFileType] = useState<'auth' | 'csv' | 'syslog'>('auth');
  const [parseStatus, setParseStatus] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      setPastedText(content);
      if (file.name.endsWith('.csv')) {
        setSelectedFileType('csv');
      } else {
        setSelectedFileType('auth');
      }
    };
    reader.readAsText(file);
  };

  const processContent = (content: string, type: 'auth' | 'csv' | 'syslog', labelName: string) => {
    if (!content.trim()) {
      setParseStatus('Error: Content is empty.');
      return;
    }

    if (type === 'csv') {
      const { data, errors } = parseNetworkFlowCsv(content);
      if (data.length === 0) {
        setParseStatus(`CSV Parse Error: ${errors.join('; ')}`);
        return;
      }
      onIngestFlowCsv(content);
      setParseStatus(`Successfully ingested ${data.length} network flow records.`);
      setTimeout(() => onClose(), 800);
    } else {
      const { logs, errors, summary } = parseLinuxAuthLog(content, 'web01');
      if (logs.length === 0) {
        setParseStatus(`Parse Error: ${errors[0] || 'No recognized log entries.'}`);
        return;
      }
      onIngestLogs(logs, labelName);
      setParseStatus(`Parsed ${summary.totalParsed} events (${summary.failedAuthCount} failed logins, ${summary.sudoViolations} sudo events).`);
      setTimeout(() => onClose(), 800);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-[#111622] border border-[#1e2a3c] rounded-lg max-w-2xl w-full shadow-2xl flex flex-col font-mono text-xs text-slate-300">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-[#1b2536] bg-[#0c1017]">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 rounded bg-lime-950/80 text-lime-400 border border-lime-800">
              <Upload className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white uppercase tracking-wider">
                Log Ingestion & File Parser
              </h2>
              <span className="text-[10px] text-slate-400">
                Safe offline log parsing for Linux Auth, Syslog, & Network Flow CSV
              </span>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded hover:bg-[#1a2333]"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab selection */}
        <div className="flex border-b border-[#1b2536] px-4 pt-2 bg-[#0d121c]">
          <button
            onClick={() => setActiveTab('samples')}
            className={`py-2 px-3 border-b-2 font-bold transition-colors ${
              activeTab === 'samples'
                ? 'border-lime-400 text-lime-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Pre-loaded Sample Datasets
          </button>
          <button
            onClick={() => setActiveTab('upload')}
            className={`py-2 px-3 border-b-2 font-bold transition-colors ${
              activeTab === 'upload'
                ? 'border-lime-400 text-lime-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Upload File / Paste Raw Text
          </button>
        </div>

        {/* Body */}
        <div className="p-5 space-y-4">
          {activeTab === 'samples' ? (
            <div className="space-y-3">
              <div className="text-[11px] text-slate-400">
                Select an authentic defensive scenario to test parsing, intrusion detection, and Isolation Forest anomaly scoring:
              </div>

              <div
                onClick={() => processContent(SAMPLE_AUTH_LOG, 'auth', 'Sample Linux auth.log')}
                className="p-3 rounded bg-[#090d15] border border-slate-800 hover:border-lime-500 cursor-pointer transition-all flex items-center justify-between group"
              >
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <FileText className="w-4 h-4 text-lime-400" />
                    <span className="text-white font-bold group-hover:text-lime-300">
                      Linux SSH Brute-Force & Sudo Exploit (auth.log)
                    </span>
                    <span className="px-1.5 py-0.2 rounded bg-lime-950 text-lime-400 text-[9px] border border-lime-800">
                      Sample Dataset
                    </span>
                  </div>
                  <div className="text-[10px] text-slate-400">
                    Contains repeated failed password sprays, invalid user enumeration, and unauthorized sudo execution attempts.
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-slate-500 group-hover:text-lime-400" />
              </div>

              <div
                onClick={() => processContent(SAMPLE_NETWORK_FLOW_CSV, 'csv', 'Sample NetFlow CSV')}
                className="p-3 rounded bg-[#090d15] border border-slate-800 hover:border-lime-500 cursor-pointer transition-all flex items-center justify-between group"
              >
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <Database className="w-4 h-4 text-cyan-400" />
                    <span className="text-white font-bold group-hover:text-cyan-300">
                      CIC-IDS Network Flow Multivariate CSV
                    </span>
                    <span className="px-1.5 py-0.2 rounded bg-cyan-950 text-cyan-400 text-[9px] border border-cyan-800">
                      Sample Dataset
                    </span>
                  </div>
                  <div className="text-[10px] text-slate-400">
                    21 numeric flow records with ground-truth labels for Isolation Forest evaluation & confusion matrix.
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-slate-500 group-hover:text-cyan-400" />
              </div>

              <div
                onClick={() => processContent(SAMPLE_SYSLOG, 'syslog', 'Sample Syslog / Nginx')}
                className="p-3 rounded bg-[#090d15] border border-slate-800 hover:border-lime-500 cursor-pointer transition-all flex items-center justify-between group"
              >
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <FileText className="w-4 h-4 text-amber-400" />
                    <span className="text-white font-bold group-hover:text-amber-300">
                      Nginx & Firewall Audit Stream (syslog)
                    </span>
                    <span className="px-1.5 py-0.2 rounded bg-amber-950 text-amber-400 text-[9px] border border-amber-800">
                      Sample Dataset
                    </span>
                  </div>
                  <div className="text-[10px] text-slate-400">
                    Path traversal query scanning, XML-RPC brute force, and UFW perimeter blocks.
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-slate-500 group-hover:text-amber-400" />
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              {/* File upload input */}
              <div className="border-2 border-dashed border-slate-700 hover:border-slate-500 rounded p-4 text-center cursor-pointer bg-[#090d15]">
                <input
                  type="file"
                  accept=".log,.txt,.csv"
                  onChange={handleFileUpload}
                  className="hidden"
                  id="file-upload-input"
                />
                <label htmlFor="file-upload-input" className="cursor-pointer block">
                  <Upload className="w-6 h-6 mx-auto text-slate-400 mb-1" />
                  <span className="text-slate-200 font-bold block">
                    Click to select file (.log, .txt, .csv)
                  </span>
                  <span className="text-[10px] text-slate-500">
                    Data remains strictly local/in-memory in your browser
                  </span>
                </label>
              </div>

              {/* Paste textarea */}
              <div>
                <label className="text-slate-400 text-[10px] block mb-1">
                  Or paste raw log / CSV contents here:
                </label>
                <textarea
                  rows={6}
                  value={pastedText}
                  onChange={(e) => setPastedText(e.target.value)}
                  placeholder="Paste raw log lines or CSV text..."
                  className="w-full bg-[#080b10] border border-slate-800 rounded p-2.5 text-[11px] text-lime-400 focus:outline-none focus:border-cyan-500 font-mono"
                />
              </div>

              {/* Format selector */}
              <div className="flex items-center space-x-3 text-[11px]">
                <span className="text-slate-400">Format:</span>
                <label className="flex items-center space-x-1 cursor-pointer">
                  <input
                    type="radio"
                    name="filetype"
                    checked={selectedFileType === 'auth'}
                    onChange={() => setSelectedFileType('auth')}
                  />
                  <span>Linux auth.log / secure</span>
                </label>
                <label className="flex items-center space-x-1 cursor-pointer">
                  <input
                    type="radio"
                    name="filetype"
                    checked={selectedFileType === 'csv'}
                    onChange={() => setSelectedFileType('csv')}
                  />
                  <span>Network Flow CSV</span>
                </label>
              </div>

              <button
                onClick={() => processContent(pastedText, selectedFileType, 'Uploaded Log File')}
                className="w-full py-2 rounded bg-lime-900/60 hover:bg-lime-800/80 text-lime-300 font-bold border border-lime-700 transition-colors"
              >
                Parse & Ingest into SentinelX
              </button>
            </div>
          )}

          {parseStatus && (
            <div className="p-2.5 rounded bg-[#0b1424] border border-cyan-800 text-cyan-300 text-xs">
              {parseStatus}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-[#1b2536] bg-[#0c1017] flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-white text-xs font-mono"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
