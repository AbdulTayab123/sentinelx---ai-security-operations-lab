import React from 'react';
import { Sliders, Trash2, Database, Shield, Lock, RotateCcw } from 'lucide-react';

interface ConfigViewProps {
  onPurgeData: () => void;
  onResetAll: () => void;
  eventCount: number;
  alertCount: number;
}

export const ConfigView: React.FC<ConfigViewProps> = ({
  onPurgeData,
  onResetAll,
  eventCount,
  alertCount
}) => {
  return (
    <div className="p-4 space-y-4 font-mono select-none">
      <div className="bg-[#111622] border border-[#1b2536] rounded p-4">
        <h2 className="text-sm font-bold text-white uppercase tracking-wider">
          SentinelX Engine & Data Governance Configuration
        </h2>
        <p className="text-xs text-slate-400 mt-0.5">
          Privacy-first, offline-first security log pipeline. No telemetry or unauthorized external network requests.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Memory & Storage Management */}
        <div className="bg-[#111622] border border-[#1b2536] p-4 rounded space-y-3">
          <h3 className="text-xs font-bold text-slate-200 uppercase flex items-center">
            <Database className="w-4 h-4 text-cyan-400 mr-2" />
            Data Lifecycle & Memory Purge
          </h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            In accordance with defensive guidelines, uploaded logs are held strictly in browser memory. You can purge the event buffer or restore factory baseline presets at any time.
          </p>

          <div className="p-3 bg-[#0a0d14] rounded border border-slate-800 text-xs space-y-1.5">
            <div className="flex justify-between">
              <span className="text-slate-400">Current Ingested Events:</span>
              <span className="text-white font-bold">{eventCount}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Active Alert Incidents:</span>
              <span className="text-red-400 font-bold">{alertCount}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Storage Retention Mode:</span>
              <span className="text-lime-400">Transient RAM-only</span>
            </div>
          </div>

          <div className="flex space-x-2 pt-2">
            <button
              onClick={onPurgeData}
              className="flex-1 py-2 rounded bg-red-950/80 hover:bg-red-900 text-red-200 border border-red-800 text-xs font-bold flex items-center justify-center space-x-1.5 transition-colors"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Purge Uploaded Data</span>
            </button>
            <button
              onClick={onResetAll}
              className="flex-1 py-2 rounded bg-[#162030] hover:bg-[#1f2d44] text-slate-200 border border-slate-700 text-xs font-bold flex items-center justify-center space-x-1.5 transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5 text-amber-400" />
              <span>Reset Factory Presets</span>
            </button>
          </div>
        </div>

        {/* Security Parameters */}
        <div className="bg-[#111622] border border-[#1b2536] p-4 rounded space-y-3">
          <h3 className="text-xs font-bold text-slate-200 uppercase flex items-center">
            <Shield className="w-4 h-4 text-lime-400 mr-2" />
            Defensive Compliance Parameters
          </h3>
          <div className="space-y-2 text-xs text-slate-300">
            <div className="p-2.5 bg-[#0a0d14] rounded border border-slate-800">
              <strong className="text-white block mb-0.5">Strict Offline Execution</strong>
              <span className="text-[11px] text-slate-400">No telemetry pings or external metric trackers. All parsing and ML trees execute locally.</span>
            </div>
            <div className="p-2.5 bg-[#0a0d14] rounded border border-slate-800">
              <strong className="text-white block mb-0.5">Safe Regex Evaluator</strong>
              <span className="text-[11px] text-slate-400">ReDoS safe timeouts on custom rule pattern matching to prevent catastrophic backtracking.</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
