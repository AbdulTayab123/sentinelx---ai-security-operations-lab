import React from 'react';
import { Server, CheckCircle2, XCircle, ShieldCheck } from 'lucide-react';
import { Agent } from '../types/security';

interface AgentsViewProps {
  agents: Agent[];
}

export const AgentsView: React.FC<AgentsViewProps> = ({ agents }) => {
  return (
    <div className="p-4 space-y-4 font-mono select-none">
      <div className="bg-[#111622] border border-[#1b2536] rounded p-4 flex items-center justify-between">
        <div>
          <h2 className="text-sm font-bold text-white uppercase tracking-wider">
            SOC Agent Fleet Management
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            489 deployed endpoint sensors monitoring Linux servers, databases, and perimeter firewalls.
          </p>
        </div>

        <div className="flex items-center space-x-3 text-xs">
          <div className="px-3 py-1 rounded bg-emerald-950/80 text-emerald-300 border border-emerald-800">
            461 Online
          </div>
          <div className="px-3 py-1 rounded bg-red-950/80 text-red-300 border border-red-800">
            28 Offline
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        {agents.map((agent) => (
          <div
            key={agent.id}
            className="p-3.5 bg-[#111622] border border-[#1b2536] rounded space-y-2 hover:border-slate-600 transition-colors"
          >
            <div className="flex items-center justify-between">
              <span className="font-bold text-white flex items-center text-xs">
                <Server className="w-3.5 h-3.5 mr-1.5 text-cyan-400" />
                {agent.name}
              </span>
              <span className={`flex items-center text-[10px] px-2 py-0.5 rounded ${
                agent.status === 'Online'
                  ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                  : 'bg-red-950 text-red-400 border border-red-800'
              }`}>
                {agent.status === 'Online' ? (
                  <CheckCircle2 className="w-3 h-3 mr-1" />
                ) : (
                  <XCircle className="w-3 h-3 mr-1" />
                )}
                {agent.status}
              </span>
            </div>

            <div className="space-y-1 text-[11px] text-slate-400">
              <div className="flex justify-between">
                <span>Internal IP:</span>
                <span className="text-slate-200">{agent.ip}</span>
              </div>
              <div className="flex justify-between">
                <span>OS / Kernel:</span>
                <span className="text-slate-200">{agent.os}</span>
              </div>
              <div className="flex justify-between">
                <span>Wazuh Version:</span>
                <span className="text-slate-200">{agent.version}</span>
              </div>
              <div className="flex justify-between">
                <span>Fleet Tier:</span>
                <span className="text-cyan-400">{agent.group}</span>
              </div>
              <div className="flex justify-between">
                <span>Active Alerts:</span>
                <span className="text-amber-400 font-bold">{agent.activeAlerts}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
