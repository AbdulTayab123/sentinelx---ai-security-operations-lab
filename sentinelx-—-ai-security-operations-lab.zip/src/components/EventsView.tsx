import React, { useState } from 'react';
import { Search, Terminal, Filter, RefreshCw } from 'lucide-react';
import { EventLog } from '../types/security';

interface EventsViewProps {
  events: EventLog[];
  onRefreshEvents: () => void;
}

export const EventsView: React.FC<EventsViewProps> = ({ events, onRefreshEvents }) => {
  const [filterQuery, setFilterQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState('ALL');

  const filtered = events.filter(e => {
    const matchesQuery = 
      e.rawText.toLowerCase().includes(filterQuery.toLowerCase()) ||
      (e.sourceIp && e.sourceIp.includes(filterQuery)) ||
      (e.user && e.user.toLowerCase().includes(filterQuery.toLowerCase()));
    
    const matchesType = typeFilter === 'ALL' || e.eventType === typeFilter;
    return matchesQuery && matchesType;
  });

  return (
    <div className="p-4 space-y-4 font-mono select-none">
      <div className="flex flex-wrap items-center justify-between gap-3 bg-[#111622] p-3 rounded border border-[#1b2536]">
        <div className="flex items-center space-x-2 flex-1 min-w-[260px]">
          <Search className="w-3.5 h-3.5 text-slate-500" />
          <input
            type="text"
            placeholder="Search raw log stream (e.g. Failed, sshd, root, 185.122)..."
            value={filterQuery}
            onChange={(e) => setFilterQuery(e.target.value)}
            className="w-full bg-[#0b0e14] border border-[#1e2a3c] rounded px-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500"
          />
        </div>

        <div className="flex items-center space-x-3 text-xs">
          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="bg-[#162030] border border-slate-700 text-slate-200 rounded px-2.5 py-1 text-xs"
          >
            <option value="ALL">All Event Types</option>
            <option value="auth_failed">Failed Logins</option>
            <option value="auth_success">Successful Logins</option>
            <option value="sudo_cmd">Sudo Executions</option>
            <option value="port_scan">Network Scans</option>
          </select>

          <button
            onClick={onRefreshEvents}
            className="p-1.5 rounded bg-[#162030] hover:bg-[#1e2a40] text-slate-300 border border-slate-700"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      <div className="bg-[#090d15] border border-[#172030] rounded p-3 font-mono text-xs max-h-[600px] overflow-y-auto">
        <div className="text-[10px] text-slate-500 pb-2 mb-2 border-b border-slate-800 flex items-center justify-between">
          <span>STREAM BUFFER ({filtered.length} matching events)</span>
          <span>FORMAT: [TIMESTAMP] [HOST] [DAEMON] [MESSAGE]</span>
        </div>

        <div className="space-y-1.5">
          {filtered.map((log) => (
            <div
              key={log.id}
              className={`p-2 rounded text-[11px] leading-relaxed transition-colors border ${
                log.severity === 'Critical' ? 'bg-red-950/20 border-red-900/40 text-red-300' :
                log.severity === 'High' ? 'bg-amber-950/20 border-amber-900/40 text-amber-300' :
                'bg-[#0c121d] border-transparent text-slate-300'
              }`}
            >
              <div className="flex items-center justify-between text-[10px] text-slate-400 mb-0.5">
                <span className="text-cyan-400 font-bold">{log.timestamp} • {log.host}</span>
                <span className="uppercase text-[9px] px-1.5 py-0.2 rounded bg-slate-800 text-slate-300">
                  {log.eventType}
                </span>
              </div>
              <div className="font-mono select-all break-all">{log.rawText}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
