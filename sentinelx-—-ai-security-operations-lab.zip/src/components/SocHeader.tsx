import React, { useState } from 'react';
import { Shield, RefreshCw, ChevronDown, Bell, Settings, User, Upload, Database, Terminal } from 'lucide-react';

interface SocHeaderProps {
  criticalCount: number;
  highCount: number;
  activeTimestamp: string;
  isLive: boolean;
  onToggleLive: () => void;
  onRefresh: () => void;
  onOpenUpload: () => void;
  onLoadSample: () => void;
}

export const SocHeader: React.FC<SocHeaderProps> = ({
  criticalCount,
  highCount,
  activeTimestamp,
  isLive,
  onToggleLive,
  onRefresh,
  onOpenUpload,
  onLoadSample
}) => {
  const [showRefreshMenu, setShowRefreshMenu] = useState(false);

  return (
    <header className="w-full bg-[#0b0e14] border-b border-[#1c2433] select-none">
      {/* Top Title Bar - Exact Wazuh SOC Banner */}
      <div className="h-10 px-4 flex items-center justify-between border-b border-[#161c28] bg-[#090c12]">
        <div className="flex items-center space-x-2.5">
          {/* Wazuh stylized shield icon */}
          <div className="w-5 h-5 flex items-center justify-center rounded bg-gradient-to-br from-emerald-500 to-lime-600 text-black shadow-sm">
            <Shield className="w-3.5 h-3.5 text-black stroke-[2.5]" />
          </div>
          <span className="text-xs font-semibold tracking-wider text-slate-300 font-mono">
            WAZUH - SECURITY OPERATIONS CENTER DASHBOARD
          </span>
          <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-lime-950/60 text-lime-400 border border-lime-800/60 ml-2">
            SentinelX Engine
          </span>
        </div>

        <div className="flex items-center space-x-3 text-slate-400">
          <button
            onClick={onLoadSample}
            title="Load authentic sample logs"
            className="flex items-center space-x-1.5 text-[11px] font-mono px-2 py-0.5 rounded bg-[#161f30] hover:bg-[#1e2b42] text-slate-300 border border-slate-700/60 transition-colors"
          >
            <Database className="w-3 h-3 text-cyan-400" />
            <span>Load Sample Data</span>
          </button>

          <button
            onClick={onOpenUpload}
            title="Upload Linux auth logs, syslog or network flow CSV"
            className="flex items-center space-x-1.5 text-[11px] font-mono px-2 py-0.5 rounded bg-lime-950/60 hover:bg-lime-900/60 text-lime-300 border border-lime-700/60 transition-colors"
          >
            <Upload className="w-3 h-3 text-lime-400" />
            <span>Ingest Logs / CSV</span>
          </button>

          <div className="h-4 w-px bg-slate-800" />

          {/* Quick status icons from screenshot */}
          <div className="flex items-center space-x-1 text-[11px] font-mono px-1.5 py-0.5 rounded bg-[#131924] text-slate-300 border border-slate-800">
            <span className="text-slate-400">pq</span>
            <span className="text-lime-400 font-semibold">53</span>
          </div>

          <button title="Notifications" className="p-1 hover:text-slate-200 transition-colors relative">
            <Bell className="w-4 h-4" />
            <span className="absolute top-0.5 right-0.5 w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />
          </button>

          <button title="Settings" className="p-1 hover:text-slate-200 transition-colors">
            <Settings className="w-4 h-4" />
          </button>

          <div className="w-6 h-6 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-slate-300 text-xs">
            <User className="w-3.5 h-3.5" />
          </div>
        </div>
      </div>

      {/* Main Subheader - "ACTIVE SECURITY MONITORING" matching screenshot */}
      <div className="px-6 py-2.5 flex flex-wrap items-center justify-between gap-4 bg-[#0e121a]">
        <div>
          <h1 className="text-base font-bold tracking-tight text-white font-mono flex items-center space-x-2">
            <span>ACTIVE SECURITY MONITORING</span>
            {isLive && (
              <span className="inline-flex items-center px-1.5 py-0.2 rounded text-[10px] font-mono bg-emerald-950 text-emerald-400 border border-emerald-800">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mr-1 animate-ping" />
                LIVE
              </span>
            )}
          </h1>
          <p className="text-xs text-slate-400 font-mono tracking-wide mt-0.5">
            {activeTimestamp}
          </p>
        </div>

        <div className="flex items-center space-x-2.5">
          {/* Critical badge */}
          <div className="flex items-center space-x-1.5 px-3 py-1 rounded bg-[#3b1219] border border-red-800/80 text-red-200 text-xs font-mono font-semibold shadow-sm">
            <span className="text-red-400 text-sm leading-none">▲</span>
            <span>Critical: {criticalCount}</span>
          </div>

          {/* High badge */}
          <div className="flex items-center space-x-1.5 px-3 py-1 rounded bg-[#3b2b0f] border border-amber-700/80 text-amber-200 text-xs font-mono font-semibold shadow-sm">
            <span>High: {highCount}</span>
          </div>

          {/* Data refresh dropdown button */}
          <div className="relative">
            <button
              onClick={() => {
                onRefresh();
                setShowRefreshMenu(!showRefreshMenu);
              }}
              className="flex items-center space-x-2 px-3 py-1 rounded bg-[#1e293b] hover:bg-[#283548] border border-slate-700 text-cyan-200 text-xs font-mono transition-colors shadow-sm"
            >
              <RefreshCw className={`w-3.5 h-3.5 text-cyan-400 ${isLive ? 'animate-spin' : ''}`} />
              <span>Data refresh</span>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </button>

            {showRefreshMenu && (
              <div className="absolute right-0 mt-1 w-44 bg-[#141a26] border border-slate-700 rounded shadow-xl py-1 z-50 text-xs font-mono">
                <button
                  onClick={() => {
                    onRefresh();
                    setShowRefreshMenu(false);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#1e293b] text-slate-200 flex items-center justify-between"
                >
                  <span>Refresh Now</span>
                  <RefreshCw className="w-3 h-3 text-cyan-400" />
                </button>
                <button
                  onClick={() => {
                    onToggleLive();
                    setShowRefreshMenu(false);
                  }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#1e293b] text-slate-200 flex items-center justify-between"
                >
                  <span>{isLive ? 'Pause Auto-stream' : 'Start Auto-stream'}</span>
                  <span className={`w-2 h-2 rounded-full ${isLive ? 'bg-amber-400' : 'bg-emerald-400'}`} />
                </button>
                <div className="border-t border-slate-800 my-1" />
                <div className="px-3 py-1 text-[10px] text-slate-400">
                  Buffer: 1,489 events parsed
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
