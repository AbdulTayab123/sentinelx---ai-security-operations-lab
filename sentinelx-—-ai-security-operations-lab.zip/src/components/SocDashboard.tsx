import React, { useState } from 'react';
import { MoreVertical, ChevronDown, ChevronLeft, ChevronRight, Activity, Globe, Shield, ArrowUpRight } from 'lucide-react';
import { Alert, Agent } from '../types/security';
import { 
  TOP_THREAT_SOURCES, 
  MOST_TARGETED_ASSETS, 
  ACTIVE_ALERT_SOURCE_IPS, 
  ACTIVE_ALERT_RULES, 
  THREAT_NODES 
} from '../services/sampleData';

interface SocDashboardProps {
  alerts: Alert[];
  agents: Agent[];
  onSelectAlert: (alert: Alert) => void;
  onFilterSourceIp?: (ip: string) => void;
}

export const SocDashboard: React.FC<SocDashboardProps> = ({
  alerts,
  agents,
  onSelectAlert,
  onFilterSourceIp
}) => {
  const [timelineRange, setTimelineRange] = useState('Last 6 hours');
  const [activeTabSubTable, setActiveTabSubTable] = useState<'source' | 'rules'>('source');
  const [activeMapFilter, setActiveMapFilter] = useState<string | null>(null);

  // Stats calculation
  const criticalCount = alerts.filter(a => a.severity === 'Critical').length || 147;
  const highCount = alerts.filter(a => a.severity === 'High').length || 312;
  const totalAgents = 489;
  const onlineAgents = 461;
  const offlineAgents = 28;

  return (
    <div className="w-full bg-[#0a0d14] text-slate-300 p-3 space-y-3 font-sans select-none">
      {/* Top Grid: Left (Severity Donut) + Center-Right (Real-time Alerts Table) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3">
        {/* Card 1: ALERT SEVERITY DISTRIBUTION */}
        <div className="lg:col-span-4 bg-[#111622] border border-[#1b2333] rounded p-3 flex flex-col justify-between shadow-sm">
          <div className="flex items-center justify-between border-b border-[#182030] pb-2 mb-2">
            <span className="text-[11px] font-bold tracking-wider text-slate-200 font-mono">
              ALERT SEVERITY DISTRIBUTION
            </span>
            <div className="flex items-center space-x-1 text-slate-400 text-[11px] font-mono">
              <span>Donut Chart</span>
              <button className="hover:text-slate-200 p-0.5">
                <MoreVertical className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* SVG Donut Chart Matching Screenshot (Lime Green / Olive Tone Rings) */}
          <div className="relative flex items-center justify-center py-2">
            <svg viewBox="0 0 200 200" className="w-44 h-44 drop-shadow-[0_0_12px_rgba(163,230,53,0.15)]">
              {/* Slices calculated for 32%, 14%, 45%, 9% */}
              {/* Outer track background */}
              <circle
                cx="100"
                cy="100"
                r="70"
                fill="none"
                stroke="#151d2a"
                strokeWidth="28"
              />

              {/* 1. Medium (45%) - starts at -90deg */}
              <circle
                cx="100"
                cy="100"
                r="70"
                fill="none"
                stroke="#65a30d" // olive lime
                strokeWidth="28"
                strokeDasharray="198 440" // ~45%
                strokeDashoffset="0"
                transform="rotate(-90 100 100)"
                className="transition-all hover:stroke-lime-500 cursor-pointer"
              />

              {/* 2. High (32%) */}
              <circle
                cx="100"
                cy="100"
                r="70"
                fill="none"
                stroke="#84cc16" // bright lime
                strokeWidth="28"
                strokeDasharray="140 440" // ~32%
                strokeDashoffset="-198"
                transform="rotate(-90 100 100)"
                className="transition-all hover:stroke-lime-400 cursor-pointer"
              />

              {/* 3. Critical (14%) */}
              <circle
                cx="100"
                cy="100"
                r="70"
                fill="none"
                stroke="#a3e635" // neon lime
                strokeWidth="28"
                strokeDasharray="62 440" // ~14%
                strokeDashoffset="-338"
                transform="rotate(-90 100 100)"
                className="transition-all hover:stroke-lime-300 cursor-pointer"
              />

              {/* 4. Low (9%) */}
              <circle
                cx="100"
                cy="100"
                r="70"
                fill="none"
                stroke="#3f6212" // dark lime
                strokeWidth="28"
                strokeDasharray="40 440" // ~9%
                strokeDashoffset="-400"
                transform="rotate(-90 100 100)"
                className="transition-all hover:stroke-lime-600 cursor-pointer"
              />

              {/* Inner dark center hole */}
              <circle cx="100" cy="100" r="54" fill="#111622" />

              {/* Percentage labels matching screenshot layout */}
              <text x="160" y="65" fill="#f8fafc" fontSize="11" fontWeight="700" textAnchor="middle" fontFamily="monospace">32%</text>
              <text x="156" y="152" fill="#f8fafc" fontSize="11" fontWeight="700" textAnchor="middle" fontFamily="monospace">14%</text>
              <text x="50" y="158" fill="#f8fafc" fontSize="11" fontWeight="700" textAnchor="middle" fontFamily="monospace">45%</text>
              <text x="44" y="62" fill="#f8fafc" fontSize="11" fontWeight="700" textAnchor="middle" fontFamily="monospace">9%</text>
            </svg>
          </div>

          {/* Legend matching screenshot */}
          <div className="grid grid-cols-2 gap-y-1.5 gap-x-2 text-[11px] font-mono pt-2 border-t border-[#182030] text-slate-300">
            <div className="flex items-center space-x-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-[#84cc16] inline-block" />
              <span>High (32%)</span>
            </div>
            <div className="flex items-center space-x-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-[#a3e635] inline-block" />
              <span>Critical (14%)</span>
            </div>
            <div className="flex items-center space-x-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-[#65a30d] inline-block" />
              <span>Medium (45%)</span>
            </div>
            <div className="flex items-center space-x-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-[#3f6212] inline-block" />
              <span>Low (9%)</span>
            </div>
          </div>
        </div>

        {/* Card 3: REAL-TIME SECURITY ALERTS Table (Top Right) */}
        <div className="lg:col-span-8 bg-[#111622] border border-[#1b2333] rounded p-3 flex flex-col justify-between shadow-sm overflow-hidden">
          <div className="flex items-center justify-between border-b border-[#182030] pb-2 mb-2">
            <span className="text-[11px] font-bold tracking-wider text-slate-200 font-mono">
              REAL-TIME SECURITY ALERTS
            </span>
            <div className="flex items-center space-x-2 text-slate-400 text-[11px] font-mono">
              <span className="text-emerald-400 flex items-center">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mr-1 animate-pulse" />
                Live Feed
              </span>
              <button className="hover:text-slate-200 p-0.5">
                <MoreVertical className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Sleek Alert Feed Table */}
          <div className="overflow-x-auto min-h-[170px]">
            <table className="w-full text-left text-[11px] font-mono border-collapse">
              <thead>
                <tr className="text-slate-400 border-b border-[#182030] text-[10px]">
                  <th className="py-1 px-1.5 font-medium whitespace-nowrap">Timestamp ↑</th>
                  <th className="py-1 px-1.5 font-medium">Alert ID</th>
                  <th className="py-1 px-2 font-medium">Rule Name</th>
                  <th className="py-1 px-1.5 font-medium">Agent</th>
                  <th className="py-1 px-1.5 font-medium">Severity</th>
                  <th className="py-1 px-1.5 font-medium">Source IP</th>
                  <th className="py-1 px-1.5 font-medium">Dest IP</th>
                  <th className="py-1 px-1 text-center font-medium">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#161c28]">
                {alerts.slice(0, 5).map((alert) => (
                  <tr
                    key={alert.id}
                    onClick={() => onSelectAlert(alert)}
                    className="hover:bg-[#161f2e] cursor-pointer transition-colors group"
                  >
                    <td className="py-1.5 px-1.5 text-slate-400 whitespace-nowrap text-[10px]">
                      {alert.timestamp}
                    </td>
                    <td className="py-1.5 px-1.5">
                      <span className="px-1.5 py-0.5 rounded text-[9px] bg-[#3b1219] text-red-300 border border-red-800/80 font-bold">
                        {alert.severity}
                      </span>
                    </td>
                    <td className="py-1.5 px-2 text-slate-200 max-w-[210px] truncate group-hover:text-cyan-300">
                      {alert.ruleName}
                    </td>
                    <td className="py-1.5 px-1.5 text-slate-300 whitespace-nowrap">
                      {alert.agent}
                    </td>
                    <td className="py-1.5 px-1.5">
                      <span
                        className={
                          alert.severity === 'Critical'
                            ? 'text-red-400 font-semibold'
                            : alert.severity === 'High'
                            ? 'text-amber-400 font-semibold'
                            : 'text-lime-400'
                        }
                      >
                        {alert.severity}
                      </span>
                    </td>
                    <td className="py-1.5 px-1.5 text-slate-300">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          if (onFilterSourceIp) onFilterSourceIp(alert.sourceIp);
                        }}
                        className="hover:text-cyan-400 hover:underline"
                      >
                        {alert.sourceIp}
                      </button>
                    </td>
                    <td className="py-1.5 px-1.5 text-slate-400">
                      {alert.destIp}
                    </td>
                    <td className="py-1.5 px-1 text-center text-slate-500 group-hover:text-slate-300">
                      ::
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="pt-2 border-t border-[#182030] flex items-center justify-between text-[10px] text-slate-400 font-mono">
            <span>Showing top recent alerts (Click any row for incident playbook)</span>
            <span className="text-cyan-400 hover:underline cursor-pointer">
              View all 1,489 events &rarr;
            </span>
          </div>
        </div>
      </div>

      {/* Middle Grid: Left (Active Alert Counts & Tables) + Center-Right (Global Threat Map & Event Timeline) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3">
        {/* Card 2: ACTIVE ALERT COUNTS (Middle Left Column) */}
        <div className="lg:col-span-4 bg-[#111622] border border-[#1b2333] rounded p-3 flex flex-col justify-between shadow-sm">
          <div>
            <div className="flex items-center justify-between border-b border-[#182030] pb-2 mb-2">
              <span className="text-[11px] font-bold tracking-wider text-slate-200 font-mono">
                ACTIVE ALERT COUNTS
              </span>
              <div className="flex items-center space-x-1 text-slate-400 text-[11px] font-mono">
                <span>Active Chart</span>
                <button className="hover:text-slate-200 p-0.5">
                  <MoreVertical className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Big Statistics side by side matching screenshot */}
            <div className="grid grid-cols-2 gap-3 py-2 px-1 text-center border-b border-[#182030] bg-[#0d121c]/60 rounded my-1">
              <div>
                <div className="text-[11px] font-mono text-slate-400">Critical:</div>
                <div className="text-2xl font-bold font-mono text-white tracking-tight">
                  {criticalCount}
                </div>
              </div>
              <div>
                <div className="text-[11px] font-mono text-slate-400">High:</div>
                <div className="text-2xl font-bold font-mono text-white tracking-tight">
                  {highCount}
                </div>
              </div>
            </div>

            {/* Sub-Table 1: Source IP / Agent / Severity matching screenshot */}
            <div className="overflow-x-auto my-2">
              <table className="w-full text-left text-[11px] font-mono border-collapse">
                <thead>
                  <tr className="text-slate-400 border-b border-[#182030] text-[10px]">
                    <th className="py-1 px-1">Source IP</th>
                    <th className="py-1 px-1">Agent</th>
                    <th className="py-1 px-1 text-right">Severity</th>
                    <th className="py-1 px-1 text-center w-4"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#151c28]">
                  {ACTIVE_ALERT_SOURCE_IPS.slice(0, 7).map((row, idx) => (
                    <tr key={idx} className="hover:bg-[#161f2e] transition-colors">
                      <td className="py-1 px-1 text-slate-200">{row.ip}</td>
                      <td className="py-1 px-1 text-slate-400">{row.agent}</td>
                      <td className="py-1 px-1 text-right text-slate-200 font-semibold">
                        {row.severity === 'Critical' ? 'Critical' : row.severity === 'High' ? 'High' : row.severity}
                        <span className="text-slate-500 text-[10px] ml-1">({row.count})</span>
                      </td>
                      <td className="py-1 px-1 text-center text-slate-500">⋮</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Divider and Sub-Table 2: Rule Name / Agent / Severity matching screenshot */}
            <div className="pt-2 border-t border-[#182030]">
              <table className="w-full text-left text-[11px] font-mono border-collapse">
                <thead>
                  <tr className="text-slate-400 border-b border-[#182030] text-[10px]">
                    <th className="py-1 px-1">Rule Name</th>
                    <th className="py-1 px-1">Agent</th>
                    <th className="py-1 px-1 text-right">Severity</th>
                    <th className="py-1 px-1 text-center w-4"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#151c28]">
                  {ACTIVE_ALERT_RULES.slice(0, 6).map((row, idx) => (
                    <tr key={idx} className="hover:bg-[#161f2e] transition-colors">
                      <td className="py-1 px-1 text-slate-300">{row.rule}</td>
                      <td className="py-1 px-1 text-slate-400">{row.severity}</td>
                      <td className="py-1 px-1 text-right text-slate-200 font-semibold">{row.count}</td>
                      <td className="py-1 px-1 text-center text-slate-500">⋮</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Pagination controls < > at bottom matching screenshot */}
          <div className="flex justify-end space-x-1 pt-2 border-t border-[#182030] text-slate-400">
            <button className="p-1 hover:text-slate-200 hover:bg-[#162030] rounded">
              <ChevronLeft className="w-3.5 h-3.5" />
            </button>
            <button className="p-1 hover:text-slate-200 hover:bg-[#162030] rounded">
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Center-Right Columns: Card 4 (Global Threat Map & Agent Status) + Card 5 (Event Timeline) */}
        <div className="lg:col-span-8 flex flex-col space-y-3">
          {/* Card 4: GLOBAL THREAT MAP & AGENT STATUS */}
          <div className="bg-[#111622] border border-[#1b2333] rounded p-3 shadow-sm">
            <div className="flex items-center justify-between border-b border-[#182030] pb-2 mb-2">
              <span className="text-[11px] font-bold tracking-wider text-slate-200 font-mono">
                GLOBAL THREAT MAP
              </span>
              <div className="flex items-center space-x-2 text-slate-400 text-[11px] font-mono">
                <span>Active threat connections:</span>
                <span className="text-lime-400 font-semibold">5 active</span>
                <button className="hover:text-slate-200 p-0.5">
                  <MoreVertical className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-12 gap-3 items-center">
              {/* World Map SVG with Ballistic Threat Arcs */}
              <div className="md:col-span-9 relative bg-[#090d15] rounded border border-[#172030] overflow-hidden min-h-[220px] flex items-center justify-center">
                <svg viewBox="0 0 800 400" className="w-full h-auto max-h-[260px]">
                  {/* Subtle World Map Outline / Continents */}
                  <defs>
                    <linearGradient id="arcGlow" x1="0%" y1="0%" x2="100%" y2="0%">
                      <stop offset="0%" stopColor="#ef4444" stopOpacity="0.9" />
                      <stop offset="50%" stopColor="#84cc16" stopOpacity="0.8" />
                      <stop offset="100%" stopColor="#22c55e" stopOpacity="0.9" />
                    </linearGradient>
                    <filter id="neonGlow" x="-20%" y="-20%" width="140%" height="140%">
                      <feGaussianBlur stdDeviation="3" result="blur" />
                      <feMerge>
                        <feMergeNode in="blur" />
                        <feMergeNode in="SourceGraphic" />
                      </feMerge>
                    </filter>
                  </defs>

                  {/* Simplified Continental Polygons (North America, South America, Eurasia, Africa, Australia) */}
                  <g fill="#1a2536" stroke="#223249" strokeWidth="0.75" opacity="0.8">
                    {/* North America */}
                    <path d="M120 70 L210 60 L240 90 L260 140 L220 180 L180 160 L140 180 L120 120 Z" />
                    {/* South America */}
                    <path d="M220 200 L280 220 L300 280 L260 360 L220 320 L210 240 Z" />
                    {/* Europe */}
                    <path d="M380 70 L460 65 L480 120 L420 150 L380 120 Z" />
                    {/* Africa */}
                    <path d="M380 160 L460 160 L480 240 L450 320 L400 320 L370 230 Z" />
                    {/* Asia / Russia */}
                    <path d="M480 60 L700 65 L720 140 L640 180 L520 170 L490 110 Z" />
                    {/* Australia */}
                    <path d="M640 250 L720 260 L730 330 L660 340 Z" />
                  </g>

                  {/* Threat Connection Ballistic Arcs from screenshot */}
                  {/* Arc 1: Ukraine (x=450, y=100) -> US Target (x=190, y=120) */}
                  <path
                    d="M 450 100 Q 320 20 190 120"
                    fill="none"
                    stroke="#a3e635"
                    strokeWidth="2.5"
                    filter="url(#neonGlow)"
                    strokeDasharray="6 3"
                    className="animate-pulse"
                  />
                  {/* Arc 2: China (x=600, y=140) -> US Target (x=190, y=120) */}
                  <path
                    d="M 600 140 Q 380 10 190 120"
                    fill="none"
                    stroke="#84cc16"
                    strokeWidth="2.2"
                    filter="url(#neonGlow)"
                  />
                  {/* Arc 3: Russia (x=530, y=80) -> US Target */}
                  <path
                    d="M 530 80 Q 360 40 190 120"
                    fill="none"
                    stroke="#bef264"
                    strokeWidth="1.8"
                  />
                  {/* Arc 4: Brazil (x=260, y=260) -> US Target */}
                  <path
                    d="M 260 260 Q 200 200 190 120"
                    fill="none"
                    stroke="#65a30d"
                    strokeWidth="2"
                  />
                  {/* Arc 5: China -> Ukraine */}
                  <path
                    d="M 600 140 Q 520 100 450 100"
                    fill="none"
                    stroke="#4d7c0f"
                    strokeWidth="1.5"
                  />

                  {/* Pulsing Nodes with Labels matching screenshot */}
                  {/* Ukraine */}
                  <g className="cursor-pointer" onClick={() => setActiveMapFilter('Ukraine')}>
                    <circle cx="450" cy="100" r="10" fill="#a3e635" opacity="0.3" className="animate-radar" />
                    <circle cx="450" cy="100" r="5" fill="#a3e635" />
                    <text x="450" y="90" fill="#bef264" fontSize="10" fontWeight="bold" textAnchor="middle" fontFamily="monospace">Ukraine</text>
                  </g>

                  {/* China */}
                  <g className="cursor-pointer" onClick={() => setActiveMapFilter('China')}>
                    <circle cx="600" cy="140" r="12" fill="#84cc16" opacity="0.3" className="animate-radar" />
                    <circle cx="600" cy="140" r="6" fill="#84cc16" />
                    <text x="600" y="160" fill="#bef264" fontSize="10" fontWeight="bold" textAnchor="middle" fontFamily="monospace">China</text>
                  </g>

                  {/* Russia */}
                  <g className="cursor-pointer" onClick={() => setActiveMapFilter('Russia')}>
                    <circle cx="530" cy="80" r="9" fill="#a3e635" opacity="0.25" className="animate-radar" />
                    <circle cx="530" cy="80" r="4.5" fill="#a3e635" />
                    <text x="530" y="70" fill="#bef264" fontSize="10" fontWeight="bold" textAnchor="middle" fontFamily="monospace">Russia</text>
                  </g>

                  {/* Brazil */}
                  <g className="cursor-pointer" onClick={() => setActiveMapFilter('Brazil')}>
                    <circle cx="260" cy="260" r="8" fill="#65a30d" opacity="0.3" className="animate-radar" />
                    <circle cx="260" cy="260" r="4.5" fill="#65a30d" />
                    <text x="260" y="278" fill="#bef264" fontSize="10" fontWeight="bold" textAnchor="middle" fontFamily="monospace">Brazil</text>
                  </g>

                  {/* US Target Hub */}
                  <g className="cursor-pointer">
                    <circle cx="190" cy="120" r="14" fill="#38bdf8" opacity="0.2" className="animate-ping" />
                    <circle cx="190" cy="120" r="6" fill="#0284c7" stroke="#38bdf8" strokeWidth="2" />
                    <text x="190" y="145" fill="#7dd3fc" fontSize="10" fontWeight="bold" textAnchor="middle" fontFamily="monospace">US (Ingress)</text>
                  </g>
                </svg>

                {/* Floating Map Overlay Info */}
                <div className="absolute bottom-2 left-2 px-2 py-1 bg-[#111622]/90 rounded border border-slate-800 text-[10px] font-mono text-slate-300">
                  <span>Selected Origin: </span>
                  <span className="text-lime-400 font-semibold">{activeMapFilter || 'All Ingress Nodes'}</span>
                </div>
              </div>

              {/* AGENT STATUS Card (Right inside Map Block matching screenshot) */}
              <div className="md:col-span-3 bg-[#0d121c] border border-[#182030] rounded p-2.5 flex flex-col justify-between h-full">
                <div className="flex items-center justify-between border-b border-[#182030] pb-1.5 mb-2">
                  <span className="text-[10px] font-bold tracking-wider text-slate-200 font-mono">
                    AGENT STATUS
                  </span>
                  <button className="text-slate-500 hover:text-slate-300">
                    <MoreVertical className="w-3 h-3" />
                  </button>
                </div>

                <div className="space-y-2 text-xs font-mono">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Total:</span>
                    <span className="text-white font-bold text-sm">{totalAgents}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Online:</span>
                    <span className="text-lime-400 font-bold text-sm">{onlineAgents}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Offline:</span>
                    <span className="text-red-400 font-bold text-sm">{offlineAgents}</span>
                  </div>
                </div>

                {/* Small wave sparkline graph matching screenshot */}
                <div className="pt-2 border-t border-[#182030] mt-2">
                  <svg viewBox="0 0 100 24" className="w-full h-6 text-lime-400">
                    <path
                      d="M 0 18 Q 20 6 40 14 T 70 8 T 100 12"
                      fill="none"
                      stroke="#84cc16"
                      strokeWidth="2"
                    />
                  </svg>
                  <div className="text-[9px] text-slate-500 text-right font-mono">94.3% Health</div>
                </div>
              </div>
            </div>
          </div>

          {/* Card 5: EVENT TIMELINE (Area Chart / Last 6 hours) */}
          <div className="bg-[#111622] border border-[#1b2333] rounded p-3 shadow-sm">
            <div className="flex items-center justify-between border-b border-[#182030] pb-2 mb-2">
              <span className="text-[11px] font-bold tracking-wider text-slate-200 font-mono">
                EVENT TIMELINE
              </span>
              <div className="flex items-center space-x-2 text-slate-400 text-[11px] font-mono">
                <span>Area Chart</span>
                <div className="relative inline-block">
                  <select
                    value={timelineRange}
                    onChange={(e) => setTimelineRange(e.target.value)}
                    className="bg-[#162030] border border-slate-700 text-slate-200 rounded px-2 py-0.5 text-[10px] font-mono appearance-none pr-5 cursor-pointer"
                  >
                    <option>Last 6 hours</option>
                    <option>Last 12 hours</option>
                    <option>Last 24 hours</option>
                  </select>
                  <ChevronDown className="w-3 h-3 text-slate-400 absolute right-1.5 top-1.5 pointer-events-none" />
                </div>
                <button className="hover:text-slate-200 p-0.5">
                  <MoreVertical className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Glowing Spline Area Chart with Y-axis EPS 0..160 matching screenshot */}
            <div className="relative pt-1 pb-1">
              <div className="flex items-center">
                {/* Y-axis EPS values */}
                <div className="w-10 text-[9px] font-mono text-slate-400 space-y-2 text-right pr-2 select-none">
                  <div>160</div>
                  <div>150</div>
                  <div>120</div>
                  <div>90</div>
                  <div>60</div>
                  <div>30</div>
                  <div>0</div>
                </div>

                {/* SVG Area Waveform */}
                <div className="flex-1 h-36 relative bg-[#0a0e16]/60 rounded border border-[#161f2d] overflow-hidden">
                  <svg viewBox="0 0 500 140" preserveAspectRatio="none" className="w-full h-full">
                    <defs>
                      <linearGradient id="areaGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#84cc16" stopOpacity="0.5" />
                        <stop offset="100%" stopColor="#84cc16" stopOpacity="0.02" />
                      </linearGradient>
                    </defs>

                    {/* Horizontal gridlines */}
                    <line x1="0" y1="20" x2="500" y2="20" stroke="#162030" strokeDasharray="3 3" />
                    <line x1="0" y1="50" x2="500" y2="50" stroke="#162030" strokeDasharray="3 3" />
                    <line x1="0" y1="80" x2="500" y2="80" stroke="#162030" strokeDasharray="3 3" />
                    <line x1="0" y1="110" x2="500" y2="110" stroke="#162030" strokeDasharray="3 3" />

                    {/* Filled Area Chart matching screenshot peaks & valleys */}
                    <path
                      d="M 0 135 
                         L 0 110 
                         Q 30 115 50 100 
                         T 100 95 
                         T 140 120 
                         T 180 30 
                         T 220 90 
                         T 260 25 
                         T 300 80 
                         T 340 30 
                         T 380 95 
                         T 420 40 
                         T 460 75 
                         T 500 65 
                         L 500 140 
                         L 0 140 Z"
                      fill="url(#areaGradient)"
                    />

                    {/* Foreground Glowing Stroke */}
                    <path
                      d="M 0 110 
                         Q 30 115 50 100 
                         T 100 95 
                         T 140 120 
                         T 180 30 
                         T 220 90 
                         T 260 25 
                         T 300 80 
                         T 340 30 
                         T 380 95 
                         T 420 40 
                         T 460 75 
                         T 500 65"
                      fill="none"
                      stroke="#a3e635"
                      strokeWidth="2.5"
                    />

                    {/* Second subtle line: Authentication events */}
                    <path
                      d="M 0 125 Q 60 120 120 110 T 240 70 T 360 85 T 500 90"
                      fill="none"
                      stroke="#facc15"
                      strokeWidth="1.2"
                      strokeDasharray="2 2"
                    />
                  </svg>
                </div>
              </div>

              {/* X-axis Timeline labels */}
              <div className="flex justify-between pl-10 pr-2 pt-1 text-[9px] font-mono text-slate-500">
                <span>3h</span>
                <span>4h</span>
                <span>5h</span>
                <span>6h</span>
                <span>8h</span>
                <span>11hours</span>
              </div>

              {/* Legend matching screenshot */}
              <div className="flex items-center justify-center space-x-6 text-[11px] font-mono pt-2 text-slate-300">
                <div className="flex items-center space-x-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#a3e635] inline-block" />
                  <span>Total Events</span>
                </div>
                <div className="flex items-center space-x-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#facc15] inline-block" />
                  <span>Authentication</span>
                </div>
                <div className="flex items-center space-x-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#06b6d4] inline-block" />
                  <span>Policy Violations</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Grid: Card 6 (Top Threat Sources) + Card 7 (Most Targeted Assets) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3">
        {/* Card 6: TOP THREAT SOURCES (Horizontal Bar Chart) */}
        <div className="lg:col-span-6 bg-[#111622] border border-[#1b2333] rounded p-3 shadow-sm">
          <div className="flex items-center justify-between border-b border-[#182030] pb-2 mb-2">
            <span className="text-[11px] font-bold tracking-wider text-slate-200 font-mono">
              TOP THREAT SOURCES
            </span>
            <div className="flex items-center space-x-1 text-slate-400 text-[11px] font-mono">
              <span>Bar Chart</span>
              <button className="hover:text-slate-200 p-0.5">
                <MoreVertical className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          <div className="flex">
            {/* Y-axis label */}
            <div className="w-6 flex items-center justify-center">
              <span className="transform -rotate-90 text-[10px] font-mono text-slate-500 whitespace-nowrap">
                Source IP
              </span>
            </div>

            {/* Horizontal Bar Chart matching screenshot exactly */}
            <div className="flex-1 space-y-1.5 pt-1">
              {TOP_THREAT_SOURCES.map((item, index) => {
                // Max width is 150
                const widthPercent = Math.min(100, Math.round((item.count / 150) * 100));

                return (
                  <div key={index} className="flex items-center text-[10px] font-mono">
                    <span className="w-24 text-slate-300 truncate pr-2 text-right">
                      {item.ip}
                    </span>
                    <div className="flex-1 h-3.5 bg-[#090d15] rounded overflow-hidden mr-2">
                      <div
                        className="h-full bg-[#a3e635] hover:bg-[#bef264] transition-all cursor-pointer rounded-r"
                        style={{ width: `${widthPercent}%` }}
                        title={`${item.ip}: ${item.count} events`}
                      />
                    </div>
                  </div>
                );
              })}

              {/* X-axis labels: 0, 50, 100, 150 */}
              <div className="flex justify-between pl-24 pr-2 pt-1 border-t border-[#182030] text-[9px] font-mono text-slate-500">
                <span>0</span>
                <span>50</span>
                <span>100</span>
                <span>150</span>
              </div>
              <div className="text-center text-[9px] font-mono text-slate-500">
                Event Count
              </div>
            </div>
          </div>
        </div>

        {/* Card 7: MOST TARGETED ASSETS (List of Hostnames matching screenshot) */}
        <div className="lg:col-span-6 bg-[#111622] border border-[#1b2333] rounded p-3 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between border-b border-[#182030] pb-2 mb-2">
              <span className="text-[11px] font-bold tracking-wider text-slate-200 font-mono">
                MOST TARGETED ASSETS
              </span>
              <button className="hover:text-slate-200 p-0.5 text-slate-400">
                <MoreVertical className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="text-[10px] font-mono text-slate-400 mb-1.5 px-1">
              Hostnames
            </div>

            <div className="space-y-1">
              {MOST_TARGETED_ASSETS.map((asset, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between px-2.5 py-1.5 rounded bg-[#0d121c] border border-[#182232] hover:border-slate-600 text-xs font-mono transition-colors group"
                >
                  <div className="flex items-center space-x-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-red-400" />
                    <span className="text-slate-200 font-medium group-hover:text-cyan-300">
                      {asset.name}
                    </span>
                    <span className="text-slate-500 text-[10px]">({asset.type})</span>
                  </div>

                  <div className="flex items-center space-x-3 text-[11px]">
                    <span className="text-slate-400">{asset.ip}</span>
                    <span className="px-1.5 py-0.2 rounded text-[10px] bg-red-950/80 text-red-300 border border-red-800">
                      {asset.attacks} attacks
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="pt-2 border-t border-[#182030] flex items-center justify-between text-[10px] font-mono text-slate-500">
            <span>Critical Assets Protected: 7/7</span>
            <span className="text-lime-400">SOC Sensor Active</span>
          </div>
        </div>
      </div>
    </div>
  );
};
