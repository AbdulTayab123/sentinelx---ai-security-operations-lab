export type Severity = 'Critical' | 'High' | 'Medium' | 'Low';

export interface Alert {
  id: string;
  timestamp: string;
  ruleName: string;
  agent: string;
  severity: Severity;
  sourceIp: string;
  destIp: string;
  status: 'Active' | 'Investigating' | 'Resolved' | 'Suppressed';
  count: number;
  mitreTactic?: string;
  mitreTechniqueId?: string;
  description: string;
  rawLog?: string;
  recommendation?: string;
  user?: string;
  port?: number;
  location?: string;
}

export interface Agent {
  id: string;
  name: string;
  ip: string;
  os: string;
  status: 'Online' | 'Offline';
  lastKeepAlive: string;
  version: string;
  group: string;
  activeAlerts: number;
}

export interface EventLog {
  id: string;
  timestamp: string;
  host: string;
  service: string;
  eventType: 'auth_failed' | 'auth_success' | 'sudo_cmd' | 'port_scan' | 'malformed_req' | 'system';
  message: string;
  user?: string;
  sourceIp?: string;
  destIp?: string;
  port?: number;
  rawText: string;
  severity: Severity;
}

export interface DetectionRule {
  id: string;
  name: string;
  description: string;
  severity: Severity;
  enabled: boolean;
  category: 'Authentication' | 'Network' | 'Privilege' | 'Web' | 'System';
  conditionType: 'failed_login_threshold' | 'regex_pattern' | 'port_scan' | 'anomaly_score' | 'sudo_violation';
  threshold?: number;
  windowSeconds?: number;
  pattern?: string;
  matchedCount: number;
  mitreId: string;
  mitreTactic: string;
  playbook: string;
}

export interface ThreatNode {
  id: string;
  name: string;
  x: number; // SVG coordinate percent (0-100)
  y: number; // SVG coordinate percent (0-100)
  ip: string;
  country: string;
  activeAttacks: number;
  threatLevel: Severity;
}

export interface ThreatConnection {
  id: string;
  source: ThreatNode;
  target: ThreatNode;
  severity: Severity;
  attackType: string;
}

export interface NetworkFlowDataPoint {
  id: string;
  timestamp: string;
  duration: number;
  protocol: 'TCP' | 'UDP' | 'ICMP';
  srcBytes: number;
  dstBytes: number;
  packetRate: number;
  errorRate: number;
  sameSrvRate: number;
  anomalyScore: number;
  isAnomaly: boolean;
  groundTruthLabel?: 0 | 1; // 0 = Normal, 1 = Attack
  flaggedReason: string;
}

export interface ModelEvaluation {
  totalEvaluated: number;
  accuracy: number;
  precision: number;
  recall: number;
  f1Score: number;
  falsePositiveRate: number;
  confusionMatrix: {
    tp: number;
    fp: number;
    tn: number;
    fn: number;
  };
  rocCurve: Array<{ fpr: number; tpr: number }>;
}
