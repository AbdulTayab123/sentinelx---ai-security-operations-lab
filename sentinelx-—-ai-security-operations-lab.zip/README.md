# SentinelX — AI Security Operations Lab

A professional Security Operations Center (SOC) dashboard, defensive cybersecurity analysis suite, and intrusion detection laboratory inspired by Wazuh, featuring genuine Isolation Forest machine learning anomaly detection and dedicated Linux hardening education.

---

## 🛡️ Visual Direction & Interface
- **SOC Aesthetic**: Deep graphite/navy `#0a0d14` palette with high-contrast neon-lime `#a3e635` accents, subtle borders, and monospace telemetry.
- **Alert Severity Distribution**: Precision SVG Donut Chart displaying High (32%), Critical (14%), Medium (45%), and Low (9%) proportions.
- **Real-Time Security Feed**: Tabular stream with severity indicators, IP origins, target agents, and single-click incident drilldown modals.
- **Global Threat Map**: Interactive vectorized world map with curved ballistic threat trajectories connecting foreign origins (Ukraine, China, Russia, Brazil) to defended infrastructure.
- **Event Timeline**: Spline area waveform plotting Events Per Second (EPS: 0 to 160) across a configurable time window.
- **Top Threat Sources & Asset Targeting**: Calibrated horizontal bar charts and host vulnerability lists.

---

## 🔍 Core Functional Capabilities

### 1. Multi-Format Defensive Log Ingestion
- **Linux Authentication Logs**: Parses `/var/log/auth.log` (Debian/Ubuntu) and `/var/log/secure` (RHEL/Rocky). Detects failed password bursts, invalid user enumeration, unauthorized `sudo` executions, and PAM lockouts.
- **Web & System Syslog**: Ingests Nginx, Apache, and UFW firewall audit lines for path traversal, SQLi, and port sweeps.
- **Multivariate Network Flow CSV**: Ingests flow records containing `duration`, `protocol`, `src_bytes`, `dst_bytes`, `packet_rate`, and `error_rate`.

### 2. Isolation Forest Anomaly Detection
- **Algorithmic Modeling**: Random recursive partitioning trees ($iTrees$) measure tree path length $E(h(x))$ relative to average unsuccessful search length $c(n)$ to calculate anomaly scores:
  $$s(x, n) = 2^{-\frac{E(h(x))}{c(n)}}$$
- **Threshold Calibration**: Real-time slider adjusting decision boundaries (0.30 – 0.85).
- **Supervised Metrics**: Evaluates labeled datasets generating:
  - **Confusion Matrix**: True Positives (TP), False Positives (FP), True Negatives (TN), False Negatives (FN)
  - **Precision, Recall, F1-Score, and False Positive Rate (FPR)**
  - **ROC Curve Coordinates**

### 3. Incident Investigation & Defensive Playbooks
- Click any alert to inspect:
  - MITRE ATT&CK technique mapping (e.g. `T1110.001 - Password Guessing`, `T1548.003 - Sudo Abuse`)
  - Raw immutable log extracts
  - Immediate defensive remediation commands (e.g. `iptables -A INPUT -s <IP> -j DROP`, `fail2ban-client`)
  - AI Security Co-Pilot triage analysis
  - JSON and CSV incident exports

### 4. Linux Security Hardening Lab
Dedicated educational module covering defensive systems administration:
- **Authentication Logs**: PAM mechanics and brute-force indicators.
- **SSH Hardening Workbench**: Interactive configurator generating battle-tested `/etc/ssh/sshd_config` baselines (`PermitRootLogin no`, `PasswordAuthentication no`, `MaxAuthTries 3`).
- **File Permissions & SUID Audit**: Octal calculator and commands to find dangerous SUID binaries (`find / -perm -4000`).
- **Least Privilege & Sudoers**: Safe editing via `visudo` and auditing wildcard directives.
- **Secure Log Handling**: Append-only flags (`chattr +a`), rsyslog TLS forwarding, and auditd.

*Note: All commands are educational copy-only text. Browser execution is intentionally prohibited.*

---

## 🚀 Deployment & Installation

### Option A: Standard Full-Stack / Node Dev Server
```bash
# 1. Install dependencies
npm install

# 2. Start Vite development server on port 3000
npm run dev
```

### Option B: Python FastAPI Backend Service
```bash
# 1. Create Python virtual environment
python3 -m venv venv
source venv/bin/activate

# 2. Install backend dependencies
pip install -r backend/requirements.txt

# 3. Run FastAPI service
uvicorn backend.main:app --host 0.0.0.0 --port 8000 --reload

# 4. Run automated test suite
pytest backend/tests/
```

### Option C: Docker Compose
```bash
docker-compose up --build
```
- Frontend available at `http://localhost:3000`
- API documentation available at `http://localhost:8000/docs`

---

## 🔒 Privacy & Data Retention
SentinelX is strictly offline-first. Uploaded logs and CSV files are analyzed directly in-memory and can be immediately cleared using the **Purge Uploaded Data** button in the Config tab.
