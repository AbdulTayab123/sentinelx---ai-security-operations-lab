"""
SentinelX — AI Security Operations Lab Backend Service
FastAPI with Scikit-learn and Pandas for defensive cybersecurity anomaly detection.
"""

from fastapi import FastAPI, HTTPException, UploadFile, File, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest
from sklearn.metrics import precision_score, recall_score, f1_score, confusion_matrix, accuracy_score
import io
import re

app = FastAPI(
    title="SentinelX Cybersecurity Detection API",
    description="Defensive log parsing, behavioral heuristics, and Isolation Forest anomaly scoring.",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# In-memory transient buffer (stores only during analysis, purged on request)
transient_data_store: Dict[str, Any] = {
    "latest_evaluation": None,
    "last_parsed_logs": []
}

class FlowFeatureInput(BaseModel):
    duration: float = Field(..., ge=0.0, description="Flow duration in seconds")
    protocol: str = Field(..., description="TCP, UDP, ICMP")
    src_bytes: float = Field(..., ge=0, description="Source payload bytes")
    dst_bytes: float = Field(..., ge=0, description="Destination payload bytes")
    packet_rate: float = Field(..., ge=0, description="Packets transmitted per second")
    error_rate: float = Field(..., ge=0.0, le=1.0, description="TCP error/reset ratio")
    same_srv_rate: float = Field(default=1.0, ge=0.0, le=1.0)
    label: Optional[int] = Field(default=None, description="0=Benign, 1=Attack ground truth")

class AnomalyEvaluationResponse(BaseModel):
    total_samples: int
    anomalies_detected: int
    precision: Optional[float] = None
    recall: Optional[float] = None
    f1_score: Optional[float] = None
    accuracy: Optional[float] = None
    false_positive_rate: Optional[float] = None
    confusion_matrix: Optional[Dict[str, int]] = None
    flagged_records: List[Dict[str, Any]]

@app.get("/api/health")
def health_check():
    return {
        "status": "healthy",
        "engine": "SentinelX Defense Suite",
        "scikit_learn": "active",
        "isolation_forest": "ready"
    }

@app.post("/api/analyze/flows", response_model=AnomalyEvaluationResponse)
def analyze_network_flows(
    flows: List[FlowFeatureInput],
    contamination: float = Query(default=0.15, ge=0.01, le=0.5)
):
    if len(flows) < 3:
        raise HTTPException(status_code=400, detail="Minimum 3 flow records required for Isolation Forest fitting.")

    # Convert to DataFrame
    df = pd.DataFrame([f.model_dump() for f in flows])

    # Feature extraction & log-scaling for robust skew handling
    X = np.column_stack([
        np.log1p(df["duration"].values),
        np.log1p(df["src_bytes"].values),
        np.log1p(df["dst_bytes"].values),
        df["packet_rate"].values,
        df["error_rate"].values * 10,
        df["same_srv_rate"].values
    ])

    # Train Isolation Forest
    clf = IsolationForest(
        n_estimators=100,
        contamination=contamination,
        random_state=42
    )
    clf.fit(X)

    # -1 = anomaly, 1 = normal
    preds = clf.predict(X)
    scores = clf.score_samples(X)  # Negative anomaly score

    # Normalize scores to [0, 1] range (higher = more anomalous)
    normalized_scores = 1.0 - (scores - scores.min()) / (scores.max() - scores.min() + 1e-9)

    is_anomaly_mask = preds == -1
    df["is_anomaly"] = is_anomaly_mask
    df["anomaly_score"] = np.round(normalized_scores, 3)

    flagged_records = []
    for idx, row in df.iterrows():
        if row["is_anomaly"]:
            reason = "Multivariate isolation anomaly"
            if row["src_bytes"] > 1000000:
                reason = "Heavy egress data burst anomaly"
            elif row["error_rate"] > 0.5:
                reason = "Elevated connection failure/scan rate"
            elif row["packet_rate"] > 100:
                reason = "Packet rate volumetric surge"

            flagged_records.append({
                "index": int(idx),
                "anomaly_score": float(row["anomaly_score"]),
                "protocol": row["protocol"],
                "src_bytes": float(row["src_bytes"]),
                "reason": reason
            })

    # Supervised metrics if labels provided
    eval_metrics: Dict[str, Any] = {}
    if "label" in df.columns and df["label"].notna().sum() >= 3:
        y_true = df["label"].dropna().astype(int)
        valid_indices = df["label"].dropna().index
        y_pred = df.loc[valid_indices, "is_anomaly"].astype(int)

        cm = confusion_matrix(y_true, y_pred, labels=[0, 1])
        tn, fp, fn, tp = cm.ravel()

        eval_metrics = {
            "precision": round(float(precision_score(y_true, y_pred, zero_division=0)), 3),
            "recall": round(float(recall_score(y_true, y_pred, zero_division=0)), 3),
            "f1_score": round(float(f1_score(y_true, y_pred, zero_division=0)), 3),
            "accuracy": round(float(accuracy_score(y_true, y_pred)), 3),
            "false_positive_rate": round(float(fp / (fp + tn + 1e-9)), 3),
            "confusion_matrix": {
                "tp": int(tp),
                "fp": int(fp),
                "tn": int(tn),
                "fn": int(fn)
            }
        }

    return AnomalyEvaluationResponse(
        total_samples=len(df),
        anomalies_detected=int(is_anomaly_mask.sum()),
        flagged_records=flagged_records,
        **eval_metrics
    )

@app.post("/api/data/reset")
def reset_data():
    """Purge in-memory transient data"""
    transient_data_store["latest_evaluation"] = None
    transient_data_store["last_parsed_logs"] = []
    return {"message": "Transient security data successfully cleared."}
