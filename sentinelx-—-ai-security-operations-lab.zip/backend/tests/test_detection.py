"""
Unit tests for SentinelX FastAPI backend detection engine.
"""

from fastapi.testclient import TestClient
from backend.main import app

client = TestClient(app)

def test_health_check():
    response = client.get("/api/health")
    assert response.status_code == 200
    assert response.json()["status"] == "healthy"

def test_isolation_forest_flow_analysis():
    sample_flows = [
        {"duration": 0.02, "protocol": "TCP", "src_bytes": 240, "dst_bytes": 480, "packet_rate": 12.0, "error_rate": 0.0, "label": 0},
        {"duration": 0.01, "protocol": "TCP", "src_bytes": 180, "dst_bytes": 240, "packet_rate": 8.0, "error_rate": 0.0, "label": 0},
        {"duration": 25.4, "protocol": "TCP", "src_bytes": 9500000, "dst_bytes": 120, "packet_rate": 450.0, "error_rate": 0.95, "label": 1},
        {"duration": 0.03, "protocol": "TCP", "src_bytes": 320, "dst_bytes": 640, "packet_rate": 15.0, "error_rate": 0.0, "label": 0},
        {"duration": 18.0, "protocol": "TCP", "src_bytes": 8200000, "dst_bytes": 100, "packet_rate": 380.0, "error_rate": 0.88, "label": 1},
    ]

    response = client.post("/api/analyze/flows?contamination=0.2", json=sample_flows)
    assert response.status_code == 200
    data = response.json()
    assert data["total_samples"] == 5
    assert data["anomalies_detected"] >= 1
    assert "confusion_matrix" in data
    assert "f1_score" in data

def test_reset_data():
    response = client.post("/api/data/reset")
    assert response.status_code == 200
    assert "cleared" in response.json()["message"]
